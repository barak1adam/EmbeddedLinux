/* lesson 12-4 file name ex12-4.c, this program illustrates the usage of pipes

Description
-----------
pipes are used to communicate between two threads in a single process or
between parent and child processes.
this is an example which use pipes between two processes.
write process sends a stream to read process via fds[0][1]
read process reads the stream sent from write process via fds[0][0] and writes it to write process again via fds[1][1]
write process reads the stream sent from read process  via fds[1][0] and writes it to read process again via fds[2][1]
Finally, read process reads the stream sent from write process via fds[2][0] and prints final message


To compile me for Linux, use gcc -ggdb ex12-4.c -o ex12-4 
To execute, type:  ./ex12-4
*/



/*************  includes     *****************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>             //used for exit
#include <string.h> 


#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <error.h>

#include <inttypes.h>
/*************  definitions     *****************/
#define NUM_THREADS 2

/*************  Prototypes   *****************/
void writer (const char* message, FILE* stream);
void reader (FILE* stream1, FILE* stream2);

/*************  Globals   *****************/

/*************  main() function ****************/ 
int main() 
{
	int fds[3][2];
  	int rtn, i;
	char buffer[1024];
  	pid_t pid;

  	/* Create a pipe. File descriptors for the two ends of the pipe are
           placed in fds. */

	for (i=0; i < 3; i++)
	{
	    rtn=pipe(fds[i]);
	    if(0!=rtn)
	    {
		perror("pipe failed");
		exit(1);
	    }
	}
 	pid = fork ();
    	if (pid < 0) /* fork returns -1 on failure */
    	{
            perror("fork"); /* display error message */
            exit(0); 
    	}
	if (pid == (pid_t) 0)
	{
	    FILE *streamR[3], *streamW[3];
	    char i, buffer[1024];

    	    /* Close our copy of the write end of the file descriptor. */
	    close (fds[0][1]);
	    close (fds[1][0]);
	    close (fds[2][1]);
	    /* Convert the read file descriptor to a FILE object, and read from it. */
/*
	    streamR[0] = fdopen (fds[0][0], "r");
	    if (streamR[0] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[0][0]);
		exit(-1);
	    }
	    streamW[1] = fdopen (fds[1][1], "w");
	    if (streamW[1] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[1][1]);
		exit(-1);
	    }
	    streamR[2] = fdopen (fds[2][0], "r");
	    if (streamR[2] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[2][0]);
		exit(-1);
	    }
	    printf("Read p: streamR[0] = 0x%x\n", streamR[0]);
	    printf("Read p: streamW[1] = 0x%x\n", streamW[1]);
	    printf("Read p: streamR[2] = 0x%x\n", streamR[2]);
*/
	    for (i=0; i < 3; i++)
	    {
		streamR[i] = fdopen (fds[i][0], "r");
		if (streamR[i] == (FILE*)-1) 
		{
		    printf("error opening file: %d\n",(int)fds[i][0]);
		    exit(-1);
		}
		streamW[i] = fdopen (fds[i][1], "w");
		if (streamW[i] == (FILE*)-1) 
		{
		    printf("error opening file: %d\n",(int)fds[i][1]);
		    exit(-1);
		}
	    }

	    /* read process reads the stream sent from write process and writes it to write process again */	
	    reader (streamR[0], streamW[1]);
	    close (fds[0][0]);
	    close (fds[1][1]);

	    /* read process () reads the stream sent from write process and prints final message */

	    while (!feof (streamR[2])
         	    && !ferror (streamR[2])
         	    && fgets (buffer, sizeof (buffer), streamR[2]) != NULL)
	    	fputs (buffer, stdout);

	    close (fds[2][0]);

	    printf("Now exit read process\n");
	}
	else
	{
	    FILE *streamR[3], *streamW[3];
	    int rtn, i;

	    /* Close our copy of the read end of the file descriptor. */
	    close (fds[0][0]);
	    close (fds[1][1]);
	    close (fds[2][0]);

	    /* Convert the write file descriptor to a FILE object, and write to it. */
/*
	    streamW[0] = fdopen (fds[0][1], "w");
	    if (streamW[0] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[0][0]);
		exit(-1);
	    }
	    streamR[1] = fdopen (fds[1][0], "r");
	    if (streamR[1] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[1][1]);
		exit(-1);
	    }
	    streamW[2] = fdopen (fds[2][1], "w");
	    if (streamW[2] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[2][0]);
		exit(-1);
	    }

	    printf("Write p: streamW[0] = 0x%x\n", streamW[0]);
	    printf("Write p: streamR[1] = 0x%x\n", streamR[1]);
	    printf("Write p: streamW[2] = 0x%x\n", streamW[2]);
*/

	    for (i=0; i < 3; i++)
	    {
		streamR[i] = fdopen (fds[i][0], "r");
		if (streamR[i] == (FILE*)-1) 
		{
		    printf("error opening file: %d\n",(int)fds[i][0]);
		    exit(-1);
		}
		streamW[i] = fdopen (fds[i][1], "w");
		if (streamW[i] == (FILE*)-1) 
		{
		    printf("error opening file: %d\n",(int)fds[i][1]);
		    exit(-1);
		}
	    }

	    /* write process sends a stream to read process */
	    writer ("Hello, world.", streamW[0]);

	    close (fds[0][1]);

	    /* write process reads the stream sent from read process and writes it to read process again */
	    reader (streamR[1], streamW[2]);

	    close (fds[1][0]);
	    close (fds[2][1]);

	    printf("Now exit write process\n");
	}
	return 0;
}


/****************************************************************************/
/* Write COUNT copies of MESSAGE to STREAM, pausing for a second
   between each. */

//void writer (const char* message, int count, FILE* stream)
void writer (const char* message, FILE* stream)
{
  char buffer[1024];

    /* Write the message to the stream, and send it off immediately. */
    fprintf (stream, "%s\n", message);
    fflush (stream);

    /* Snooze a while. */
//    sleep (1);
}

/****************************************************************************/
/* Read random strings from the stream as long as possible.  */

void reader (FILE* stream1, FILE* stream2)
{
  char buffer[1024];

  /* Read until we hit the end of the stream. fgets reads until
     either a newline or the end-of-file. */

  while (!feof (stream1)
         && !ferror (stream1)
         && fgets (buffer, sizeof (buffer), stream1) != NULL)
     writer(buffer, stream2);
}
