/* lesson 12-1 file name ex12-1.c, this program illustrates the usage of pipes

Description
-----------
pipes are used to communicate between two threads in a single process or
between parent and child processes.
this is an example which use pipes between two threads.
the main function creates another processes (using fork)
the parent process writes to the fds[1] 
the child process reads from fds[0] .




To compile me for Linux, use gcc -ggdb ex12-1.c -o ex12-1 
To execute, type:  ./ex12-1
 */




/*************  includes     *****************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>             //used for exit
#include <string.h> 


#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <error.h>

#include <inttypes.h>
/*************  definitions     *****************/
#define NUM_THREADS 2

/*************  Prototypes   *****************/
//void writer (const char* message, int count, FILE* stream);
void writer (const char* message, FILE* stream);
void reader (FILE* stream);
void* readThread(void*);
void* writeThread(void*);

/*************  Globals   *****************/
pthread_t tid[NUM_THREADS];      /* array of thread IDs */
int fds[2];

/*************  main() function ****************/ 
int main() 
{
  	int rtn, i;

  	/* Create a pipe. File descriptors for the two ends of the pipe are
           placed in fds. */
	rtn=pipe(fds);
	if(0!=rtn)
	{
		perror("pipe failed");
		exit(1);
	}

	/* Create the threads */
	rtn = pthread_create(&tid[0], NULL, readThread, NULL);
	if(0!=rtn)
	{
	    perror("pthread_create");
	    exit(1);
	}
	rtn = pthread_create(&tid[1], NULL, writeThread, NULL);
	if(0!=rtn)
	{
	    perror("pthread_create");
	    exit(1);
	}

	for ( i = 0; i < NUM_THREADS; i++)
	{
	    rtn = pthread_join(tid[i], NULL);
	    if(0!=rtn)
	    {
		perror("pthread_join");
		exit(1);
	    }	
    	    printf("now thread_id %x exit\n", (int)tid[i]);
  	}

	printf("main() reporting that all %d threads have terminated\n", i);
	return 0;
}

void* readThread(void* arg)
{
	FILE* stream;

	/* Convert the read file descriptor to a FILE object, and read from it. */
	stream = fdopen (fds[0], "r");
	if (stream == (FILE*)-1) 
	{
		/* The open failed. Print an error message and exit. */
		printf("error opening file: %d\n",(int)fds[0]);
		exit(-1);
	}
	reader (stream);

	close (fds[0]);
}


void* writeThread(void* arg)
{
	FILE* stream;

	/* Convert the write file descriptor to a FILE object, and write to it. */
	stream = fdopen (fds[1], "w");

	if (stream == (FILE*)-1) 
	{
		/* The open failed. Print an error message and exit. */
		printf("error opening file: %d\n",(int)fds[1]);
		exit(-1);
	}

	writer ("Hello, world.", stream);

	close (fds[1]);
}

/****************************************************************************/
/* Write COUNT copies of MESSAGE to STREAM, pausing for a second
   between each. */

void writer (const char* message, FILE* stream)
{
    /* Write the message to the stream, and send it off immediately. */
    fprintf (stream, "%s\n", message);
    fflush (stream);
    /* Snooze a while. */
//    sleep (1);
}

/****************************************************************************/
/* Read random strings from the stream as long as possible.  */
void reader (FILE* stream)
{
  char buffer[1024];
  /* Read until we hit the end of the stream. fgets reads until
     either a newline or the end-of-file. */

  while (!feof (stream)
         && !ferror (stream)
         && fgets (buffer, sizeof (buffer), stream) != NULL)
    fputs (buffer, stdout);

}
