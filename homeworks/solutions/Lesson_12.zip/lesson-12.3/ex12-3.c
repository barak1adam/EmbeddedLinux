/* lesson 12-3 file name ex12-3.c, this program illustrates the usage of pipes

Description
-----------
pipes are used to communicate between two threads in a single process or
between parent and child processes.
this is an example which use pipes between two threads.
writeThread () sends a stream to readThread() via fds[0][1]
readThread ()  reads the stream sent from writeThread via fds[0][0] and writes it to writeThread again via fds[1][1]
writeThread () reads the stream sent from readThread  via fds[1][0] and writes it to readThread  again via fds[2][1]
Finally, readThread () reads the stream sent from writeThread via fds[2][0] and prints final message


To compile me for Linux, use gcc -ggdb ex12-3.c -o ex12-3 
To execute, type:  ./ex12-3
*/



/*************  includes     *****************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>             //used for exit
#include <string.h> 


#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <error.h>

#include <inttypes.h>
/*************  definitions     *****************/
#define NUM_THREADS 2

/*************  Prototypes   *****************/

void writer (const char* message, FILE* stream);
void reader (FILE* stream1, FILE* stream2);
void* readThread(void*);
void* writeThread(void*);

/*************  Globals   *****************/
pthread_t tid[NUM_THREADS];      /* array of thread IDs */
int fds[3][2];

/*************  main() function ****************/ 
int main() 
{
  	int rtn, i;
	char buffer[1024];

  	/* Create a pipe. File descriptors for the two ends of the pipe are
           placed in fds. */

	for (i=0; i < 3; i++)
	{
	    rtn=pipe(fds[i]);
	    if(0!=rtn)
	    {
		perror("pipe failed");
		exit(1);
	    }
	}

	/* Create the threads */

	rtn = pthread_create(&tid[0], NULL, readThread, NULL);
	if(0!=rtn)
	{
	    perror("pthread_create");
	    exit(1);
	}
	rtn = pthread_create(&tid[1], NULL, writeThread, NULL);
	if(0!=rtn)
	{
	    perror("pthread_create");
	    exit(1);
	}

	for ( i = 0; i < NUM_THREADS; i++)
	{
	    rtn = pthread_join(tid[i], NULL);
	    if(0!=rtn)
	    {
		perror("pthread_join");
		exit(1);
	    }	
    	    printf("now thread_id %x exit\n", (int)tid[i]);
  	}

	printf("main() reporting that all %d threads have terminated\n", i);
	return 0;
}


void* readThread(void* arg)
{
	FILE *streamR[3], *streamW[3];
	char i, buffer[1024];

	/* Convert the read file descriptor to a FILE object, and read from it. */
	for (i=0; i < 3; i++)
	{
	    streamR[i] = fdopen (fds[i][0], "r");
	    if (streamR[i] == (FILE*)-1) 
	    {

		printf("error opening file: %d\n",(int)fds[i][0]);
		exit(-1);
	    }
	    streamW[i] = fdopen (fds[i][1], "w");
	    if (streamW[i] == (FILE*)-1) 
	    {

		printf("error opening file: %d\n",(int)fds[i][1]);
		exit(-1);
	    }
	}

	/* readThread () reads the stream sent from writeThread and writes it to writeThread again */	
	reader (streamR[0], streamW[1]);
	close (fds[0][0]);
	close (fds[1][1]);

	/* readThread () reads the stream sent from writeThread and prints final message */

	while (!feof (streamR[2])
         	&& !ferror (streamR[2])
         	&& fgets (buffer, sizeof (buffer), streamR[2]) != NULL)
	    fputs (buffer, stdout);

	close (fds[2][0]);
}


void* writeThread(void* arg)
{
	FILE *streamR[3], *streamW[3];
	int rtn, i;

	/* Convert the write file descriptor to a FILE object, and write to it. */
	for (i=0; i < 3; i++)
	{
	    streamR[i] = fdopen (fds[i][0], "r");
	    if (streamR[i] == (FILE*)-1) 
	    {

		printf("error opening file: %d\n",(int)fds[i][0]);
		exit(-1);
	    }
	    streamW[i] = fdopen (fds[i][1], "w");
	    if (streamW[i] == (FILE*)-1) 
	    {

		printf("error opening file: %d\n",(int)fds[i][1]);
		exit(-1);
	    }
	}

	/* writeThread () sends a stream to readThread() */

	writer ("Hello, world.", streamW[0]);
	close (fds[0][1]);

	/* writeThread () reads the stream sent from readThread and writes it to readThread again */

	reader (streamR[1], streamW[2]);
	close (fds[1][0]);
	close (fds[2][1]);
}

/****************************************************************************/
/* Write COUNT copies of MESSAGE to STREAM, pausing for a second
   between each. */

void writer (const char* message, FILE* stream)
{
  char buffer[1024];

    /* Write the message to the stream, and send it off immediately. */
    fprintf (stream, "%s\n", message);
    fflush (stream);

    /* Snooze a while. */
//    sleep (1);
}

/****************************************************************************/
/* Read random strings from the stream as long as possible.  */

void reader (FILE* stream1, FILE* stream2)
{
  char buffer[1024];

  /* Read until we hit the end of the stream. fgets reads until
     either a newline or the end-of-file. */

  while (!feof (stream1)
         && !ferror (stream1)
         && fgets (buffer, sizeof (buffer), stream1) != NULL)
     writer(buffer, stream2);
}
