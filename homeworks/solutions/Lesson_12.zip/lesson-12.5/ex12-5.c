/* lesson 12-5 file name ex12-5.c, this program illustrates the usage of pipes

Description
-----------
pipes are used to communicate between two threads in a single process or
between parent and child processes.
this is an example which use pipes between two processes.
Parent process sends a stream to child1 process via fds[0][1]
Child1 process reads the stream sent from parent process via fds[0][0] and writes it to parent process again via fds[1][1]
parent process reads the stream sent from child1 process via fds[1][0] and writes it to child2 process via fds[2][1]
Finally, child2 process reads the stream sent from parent process via fds[2][0] and prints final message


To compile me for Linux, use gcc -ggdb ex12-5.c -o ex12-5 
To execute, type:  ./ex12-5
*/



/*************  includes     *****************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>             //used for exit
#include <string.h> 


#include <fcntl.h>
#include <unistd.h>
#include <assert.h>
#include <error.h>
#include <sys/wait.h>

#include <inttypes.h>

/*************  definitions     *****************/
#define NUM_OF_READ_PROCESSES	2
#define CHILD1			0
#define CHILD2			1

/*************  Prototypes   *****************/

void writer (const char* message, FILE* stream);
void reader (FILE* stream1, FILE* stream2);

/*************  Globals   *****************/


/*************  main() function ****************/ 
int main() 
{
	int fds[3][2];
  	int rtn, i, status;
	char buffer[1024];
  	pid_t pid;
	FILE *streamR[3], *streamW[3];
  	/* Create a pipe. File descriptors for the two ends of the pipe are
           placed in fds. */

	for (i=0; i < 3; i++)
	{
	    rtn=pipe(fds[i]);
	    if(0!=rtn)
	    {
		perror("pipe failed");
		exit(1);
	    }
	}

	for (i=0; i < 3; i++)
	{
	    streamR[i] = fdopen (fds[i][0], "r");
	    if (streamR[i] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[i][0]);
		exit(-1);
	    }

	    streamW[i] = fdopen (fds[i][1], "w");
	    if (streamW[i] == (FILE*)-1) 
	    {
		printf("error opening file: %d\n",(int)fds[i][1]);
		exit(-1);
	    }
	}

	for (i = 0; i < NUM_OF_READ_PROCESSES; i++) 
	{  	
	    pid = fork ();

	    if (pid < 0) /* fork returns -1 on failure */
	    {
		perror("fork"); /* display error message */
		exit(0); 
	    }
	    if (pid == (pid_t) 0)
	    {
		char buffer[1024];
		printf("CHILD%d: I am the child process\n", i);
		printf("CHILD%d: Here's my PID: %d\n", i,getpid());
 
		/* Close our copy of the write end of the file descriptor. */
		close (fds[0][1]);
		close (fds[1][0]);
		close (fds[2][1]);

		if (i == CHILD1)
		{
		    /* read1 process reads the stream sent from write process and writes it to write process again */
		    reader (streamR[0], streamW[1]);

		    close (fds[0][0]);
		    close (fds[1][1]);
		}
		else if (i == CHILD2)
		{
		    /* read2 process () reads the stream sent from write process and prints final message */

		    while (!feof (streamR[2])
			    && !ferror (streamR[2])
			    && fgets (buffer, sizeof (buffer), streamR[2]) != NULL)
			fputs (buffer, stdout);

		    close (fds[2][0]);
		}
		printf("Now exit Child%d process\n",i);
		exit(0);
	    }
	    else
	    {
		printf("\nPARENT: I am the parent process! i=%d\n", i);
		printf("PARENT: Here's my PID: %d\n", getpid());

		/* Close our copy of the read end of the file descriptor. */
		close (fds[0][0]);
		close (fds[1][1]);
//		close (fds[2][0]);
	
		/* Convert the write file descriptor to a FILE object, and write to it. */

		/* parent process sends a stream to child1 process */
		writer ("Hello, world.", streamW[0]);

		close (fds[0][1]);

		/* parent process reads the stream sent from child1 process and writes it to child2 process */
		reader (streamR[1], streamW[2]);
		close (fds[1][0]);
		close (fds[2][1]);

		if(i == 1)
		{
		    close (fds[2][0]);
		    sleep(1);				
		    printf("Now exit Parent%d process\n",i);
		    exit(0);
		}
	    }
	}//FOR loop
}


/****************************************************************************/
/* Write COUNT copies of MESSAGE to STREAM, pausing for a second
   between each. */

void writer (const char* message, FILE* stream)
{
  char buffer[1024];

    /* Write the message to the stream, and send it off immediately. */
    fprintf (stream, "%s\n", message);
    fflush (stream);

    /* Snooze a while. */
//    sleep (1);
}

/****************************************************************************/
/* Read random strings from the stream as long as possible.  */

void reader (FILE* stream1, FILE* stream2)
{
  char buffer[1024];

  /* Read until we hit the end of the stream. fgets reads until
     either a newline or the end-of-file. */

  while (!feof (stream1)
         && !ferror (stream1)
         && fgets (buffer, sizeof (buffer), stream1) != NULL)
     writer(buffer, stream2);
}
