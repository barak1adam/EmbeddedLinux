/*
 * ex10-2.c -  creates a shared memory portion, creates 10 processes,
 * each process sends a message to the next by the order they were created (1st process to 2nd process, 2nd to 3rd, etc).
 * The shared memory size is 2 bytes. The first child process (process 0) writes the character 'ab'. the next child process waits in a loop 
 * to recive the first character (child process 1 waits for 'a', process 2 for 'c', 3rd for 'e', etc...) the child reads the shared
 * memory, prints it on the screen and writes the next chars to the shared memory. (process 1 reads and displays 'ab' and writes 'cd' to
 * the next process.
 * The parent process waits in a loop until the child process i writes its data to the shared memory and then exits. on the first iteration
 * it waits for 'a', the last iteration waits for 's' (which child process 9 had written, but there are no more processes to read).
 *

  Description
  -----------
  This processes allocates the shared Memory area, then it attaches to it.
  It writes into the memory segment for the other process to read.
  The parent waits for each child to write its data, indicating that it has read the string and the new process can write the next data,
  then exits.
	  
  To compile me for Linux, use: gcc ex10-2b.c -ggdb -o ex10-2b 
 
  To execute, type:  ./ex10-2b
*/

/*************  includes     *****************/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#include <inttypes.h>
#include <string.h>
/*************  definitions     *****************/
#define SHMSZ     2
#define NUM_OF_READ_PROCESSES     10

/*************  Prototypes   *****************/
 

/*************  Globals   *****************/

/*************  main() function ****************/
main()
{
    char c, i;
    int shmid;
    key_t key;
    char *shm, *s;
    pid_t readChildpid;				/* variable to store the child's pid */


    /*
	* We'll name our shared memory segment
	* "5678".
	*/
    key = 5678;
    /*
	* Create the segment.
	*/

    if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0)
    {
	perror("shmget");
        exit(1);
    }
    /*
	* Now we attach the segment to our data space.
	*/

    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
    {
	perror("shmat");
	exit(1);
    }
    /*
	* clear the memory
	*/
    s = shm;
    memset (shm, 0, SHMSZ);

    /* now create new processes */
    for (i = 0; i < NUM_OF_READ_PROCESSES; i++) 
    { 
	readChildpid = fork();
    	if (readChildpid >= 0) /* fork succeeded */
    	{
            if (readChildpid == 0) /* fork() returns 0 to the read process */
            {

    	        /*
		   * We need to get the segment named
		   * "5678", created by the main.
		   */

     		/*
		   * Locate the segment.
		   */
 
   	  	if ((shmid = shmget(key, SHMSZ, 0666)) < 0)
	   	{
        	    perror("shmget");
        	    exit(1);
    	   	}
	
     		/*
		   * Now we attach the segment to our data space.
		   */
    	   	if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
	   	{
        	    perror("shmat");
        	    exit(1);
    	   	}
	

		s = shm;
		/*
		   * First process (0) writes the first data to the next process
		   */
		if (i == 0)
		{
  	   	   printf("CHILD: I am the read %d process\n", i);
            	   printf("CHILD: Here's my PID: %d\n", getpid());
		   printf("CHILD: I have no data to display\n");    
		   for (c = 'a' + i*2; c <= 'b' + i*2; c++)
			*s++ = c;
	   	   *s = (intptr_t)NULL;
		}
		else
		{		
    		/*
		   * Now wait until data is valid to the current process from the previous process.
		   */		   
		   while(*shm != 'a' + (i-1)*2);

   		/*
		   * Now read what the previous process put in the memory.
		   */
		   printf("CHILD: I am the read %d process\n", i);
            	   printf("CHILD: Here's my PID: %d\n", getpid());    	   	
		   printf("CHILD: ");
		   for (s = shm; *s != (intptr_t) NULL; s++)
        	   	putchar(*s);
    	   	   putchar('\n');

		/*
		   * Now put some things into the memory for the
		   * next process to read.
		   */
 	   	   s = shm;
		   for (c = 'a' + i*2; c <= 'b' + i*2; c++)
			*s++ = c;
	   	   *s = (intptr_t)NULL;
		}

		printf("CHILD: Now exit from child %d process\n",i);
	   	exit(0); /* read exits with user-provided return code */
            }
	    else
	    {
		printf("\nPARENT: I am the parent process! i=%d\n", i);
            	printf("PARENT: Here's my PID: %d\n", getpid());

		while(*shm != 'a' + i*2);

		if(i == 9)
		{
		   if (shmdt(shm) == -1)
	   	   {
        		perror("shmat");
        	    	exit(1);
    	   	   }
		   printf("PARENT: Now exit from parent process, i=%d\n\n",i);
		   exit(0);
		}
	    }
    	}
    	else /* fork returns -1 on failure */
    	{
            perror("fork"); /* display error message */
            exit(0); 
    	}
    }
    printf("exit ForLoop\n");
    exit(0);
}
