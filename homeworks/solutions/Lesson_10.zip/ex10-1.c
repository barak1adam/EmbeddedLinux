/*
 * shared_mem_server.c -  creates a shared memory portion and writes to it.
 *

  Description
  -----------
  This processes allocates the shared Memory area, then it attaches to it.
  It writes into the memory segment for the other process to read.
  Finally we wait until the other process changes the first character of the memory
  to '*', indicating that it has read the string.
  
	
	  
  To compile me for Linux, use: gcc ex10-1.c -ggdb -o ex10-1 
 
  To execute, type:  ./ex10-1
*/




/*************  includes     *****************/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>

#include <inttypes.h>
/*************  definitions     *****************/
#define SHMSZ     27

/*************  Prototypes   *****************/


/*************  Globals   *****************/


/*************  main() function ****************/
main()
{
    char c;
    int shmid;
    key_t key;
    char *shm, *s;
    pid_t readpid; /* variable to store the child's pid */

    /* now create new process */
    readpid = fork();
    if (readpid >= 0) /* fork succeeded */
    {
        if (readpid == 0) /* fork() returns 0 to the read process */
        {
    	    printf("READ: I am the read process!\n");
            printf("READ: Here's my PID: %d\n", getpid());
	   /*
	   * We need to get the segment named
	   * "5678", created by the server.
	   */
    	   key = 5678;
    	   /*
	   * Locate the segment.
	   */
    	   if ((shmid = shmget(key, SHMSZ, 0666)) < 0)
	   {
        	perror("shmget");
        	exit(1);
    	   }
	
    	   /*
	   * Now we attach the segment to our data space.
	   */
    	   if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
	   {
        	perror("shmat");
        	exit(1);
    	   }
	
   	   /*
	   * Now read what the server put in the memory.
	   */
    	   for (s = shm; *s != (intptr_t) NULL; s++)
        	putchar(*s);
    	   putchar('\n');
	
    	   /*
	   * Finally, change the first character of the 
	   * segment to '*', indicating we have read 
	   * the segment.
	   */
    	   *shm = '*';
	
	   exit(0); /* read exits with user-provided return code */
        }

        else /* fork() returns new pid to the write process */
        {
    	    printf("WRITE: I am the write process!\n");
            printf("WRITE: Here's my PID: %d\n", getpid());
	   /*
	   * We'll name our shared memory segment
	   * "5678".
	   */
    	   key = 5678;
           /*
	   * Create the segment.
	   */
    	   if ((shmid = shmget(key, SHMSZ, IPC_CREAT | 0666)) < 0)
	   {
           	perror("shmget");
           	exit(1);
	   }
	
           /*

	   * Now we attach the segment to our data space.
	   */
    	   if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
	   {
        	perror("shmat");
       		exit(1);
    	   }
	
    	   /*
	   * Now put some things into the memory for the
	   * other process to read.

	   */
    	   s = shm;
	
    	   for (c = 'a'; c <= 'z'; c++)
           *s++ = c;
	   *s = (intptr_t)NULL;
	
    	   /*
	   * Finally, we wait until the other process 
	   * changes the first character of our memory
	   * to '*', indicating that it has read what 

	   * we put there.
	   */
    	   while (*shm != '*')
        	sleep(1);

            exit(0);  /* parent server exits */       
        }
    }
    else /* fork returns -1 on failure */
    {
        perror("fork"); /* display error message */
        exit(0); 
    }
}
