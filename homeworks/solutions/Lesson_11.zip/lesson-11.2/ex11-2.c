/*
 * ex11-2.c -  creates a shared memory portion, creates 10 processes, Creates system_V semaphore 
 * each process sends a message to the next by the order they were created (1st process to 2nd process, 2nd to 3rd, etc).
 * The shared memory size is 2 bytes. The first child process (process 0) writes the character 'ab'. the next child process waits in a loop 
 * to recive the first character (child process 1 waits for 'a', process 2 for 'c', 3rd for 'e', etc...) the child reads the shared
 * memory, prints it on the screen and writes the next chars to the shared memory. (process 1 reads and displays 'ab' and writes 'cd' to
 * the next process.
 * The parent process waits in a loop until the child process i writes its data to the shared memory and then exits. on the first iteration
 * it waits for 'a', the last iteration waits for 's' (which child process 9 had written, but there are no more processes to read).
 *

  Description
  -----------
  This processes allocates the shared Memory area, then it attaches to it.
  It writes into the memory segment for the other process to read.
  The parent waits for each child to write its data, indicating that it has read the string and the new process can write the next data,
  then exits.
	  
  To compile me for Linux, use: gcc ex11-2.c -ggdb -o ex11-2 
 
  To execute, type:  ./ex11-2
*/

/*************  includes     *****************/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>

#include <inttypes.h>
#include <string.h>
/*************  definitions     *****************/
#define SHMSZ     2
#define NUM_OF_READ_PROCESSES     10

/*************  Prototypes   *****************/
 

/*************  Globals   *****************/

/*************  main() function ****************/
main()
{
    char c, i;
    int shmid, semid, semOpVal, semCtlVal;
    size_t nsops = 1;
    key_t keyShm, keySem;
    char *shm, *s;
    pid_t readChildpid;
    struct sembuf sb = {0,-1,0};

    union semnum
    {
	int val;
	struct semid_ds *buf;
	ushort *array;
    }argument;

    unsigned short values[1];

    values[0] = 1;
    argument.array = values;

    /*
	* We'll name our shared memory segment
	* "5678".
	*/
    keyShm = 5678;
    keySem = 1234;
    /*
	* Create the segment.
	*/

    if ((shmid = shmget(keyShm, SHMSZ, IPC_CREAT | 0666)) < 0)
    {
	perror("shmget");
        exit(1);
    }
    /*

	* Now we attach the segment to our data space.
	*/
    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
    {
	perror("shmat");
	exit(1);
    }

    /*
	* Alocate the semaphore.
	*/   
    if ((semid = semget(keySem, 1, IPC_CREAT | 0666)) < 0)
    {
        perror("semget");
        exit(1);
    }
    /*
	* Initialize the semaphore.
	*/   
    if(semctl(semid,0,SETALL,argument) < 0)
    {
        perror("semctl");
        exit(1);
    }

    sb.sem_flg  = SEM_UNDO;

    /* now create new processes */
    for (i = 0; i < NUM_OF_READ_PROCESSES; i++) 
    { 
	readChildpid = fork();
    	if (readChildpid < 0) /* fork returns -1 on failure */
    	{
            perror("fork"); /* display error message */
            exit(0); 
    	}

	if (readChildpid == 0) /* fork() returns 0 to the read process */
	{

	    /*
		* We need to get the segment named
		* "5678", created by the main.
		*/

	    /*
		* Locate the segment.
		*/
	    if ((shmid = shmget(keyShm, SHMSZ, 0666)) < 0)
	    {
		perror("shmget");
		exit(1);
	    }
	
	    /*
		* Now we attach the segment to our data space.
		*/
	    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
	    {
		perror("shmat");
		exit(1);
	    }

	    s = shm;

	    /*
		* Now read what the previous process put in the memory.
		*/
	    printf("CHILD: I am the read %d process\n", i);
	    printf("CHILD: Here's my PID: %d\n", getpid());    	   	
	    printf("CHILD: ");

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
		perror("semctl");
		exit(1);
	    }	   
	    printf("CHILD semCtlVal before lock semop = %d\n", semCtlVal);
	    /*
		* Lock the semaphore.
		*/
	    sb.sem_op  = -1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		perror("semop");
		exit(1);
 	    }
	    else printf("CHILD Lock success\n");

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
			perror("semctl");
			exit(1);
	    }	   
	    printf("CHILD semCtlVal after lock semop = %d\n", semCtlVal);
	    if(i > 0)
	    {
		printf("CHILD%d: ",i);
		for (s = shm; *s != (intptr_t) NULL; s++)
		    putchar(*s);
		putchar('\n');
	    }
	    else
		printf("CHILD%d: I have no data to display\n", i);    

	    /*
		* Now put some things into the memory for the
		* next process to read.
		*/
	    s = shm;
	    for (c = 'a' + i*2; c <= 'b' + i*2; c++)
		*s++ = c;
	    *s = (intptr_t)NULL;

	    /*
		* Unlock the semaphore.
		*/

	    sb.sem_op  = 1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		perror("semop");
		exit(1);
	    }
	    else printf("CHILD Unlock success\n");

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
		perror("semctl");
		exit(1);
	    }	   
	    printf("CHILD semCtlVal after unlock semop= %d\n", semCtlVal);
	    printf("CHILD: Now exit from child %d process\n",i);
	    if (i == 9)
	    {    	   
		/*
		    * Deattach the shared memory.
		    */

		if (shmdt(shm) == -1)
		{
		    perror("shmat");
		    exit(1);
		}
		printf("CHILD: Deattach the shared memory.\n");
	    }
	    exit(0); /* read exits with user-provided return code */
	}
	else
	{
	    printf("\nPARENT: I am the parent process! i=%d\n", i);

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
		perror("semctl");
		exit(1);
	    }	   
	    printf("PARENT semCtlVal before lock semop = %d\n", semCtlVal);
	
	    /*
		* Lock the semaphore.
		*/
	    sb.sem_op  = -1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		perror("semop");
		exit(1);
	    }
	    else printf("PARENT Lock success\n");

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
		perror("semctl");
		exit(1);
	    }	   
	    printf("PARENT semCtlVal after lock semop = %d\n", semCtlVal);

	    s = shm;
	    *s = *shm;

	    /*
		* Unlock the semaphore.
		*/

	    sb.sem_op  = 1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		perror("semop");
		exit(1);
	    }
	    else printf("PARENT Unlock success\n");

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
	    {
		perror("semctl");
		exit(1);
	    }	   
	    printf("PARENT semCtlVal after unlock semop= %d\n", semCtlVal);

	    while(*s != 'a' + i*2);

	    if(i == 9)
	    {
		/*
		    * Deattach the shared memory.
		    */

		if (shmdt(shm) == -1)
		{
		    perror("shmat");
		    exit(1);
		}
		printf("PARENT: Deattach the shared memory.\n");

		/*
		    * Remove the semaphore.
		    */

		if (semctl(semid, 0, IPC_RMID) < 0)
		{
		    perror("semctl");
		    exit(1);
		}

		printf("PARENT: Now exit from parent process, i=%d\n\n",i);
		exit(0);
	    }
	}//else parent
    }//FOR loop
}
