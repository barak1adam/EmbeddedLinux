/*
 * shared_mem_server.c -  creates a shared memory portion and writes to it.
 *

  Description
  -----------
  This processes allocates the shared Memory area, then it attaches to it.
  It writes into the memory segment for the other process to read.
  Finally we wait until the other process changes the first character of the memory
  to '*', indicating that it has read the string.
  
	
	  
  To compile me for Linux, use: gcc ex11-1.c -ggdb -o ex11-1 
 
  To execute, type:  ./ex11-1
*/

/*************  includes     *****************/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>

#include <inttypes.h>
/*************  definitions     *****************/
#define SHMSZ     27

/*************  Prototypes   *****************/


/*************  Globals   *****************/


/*************  main() function ****************/
main()
{
    char c;
    int shmid, semid, semOpVal, semCtlVal;
    size_t nsops = 1;
    key_t keyShm, keySem;
    char *shm, *s;
    struct sembuf sb = {0,-1,0};
    union semnum
    {
	int val;
	struct semid_ds *buf;
	ushort *array;
    }argument;

    unsigned short values[1];

    values[0] = 1;
    argument.array = values;
    pid_t readpid; /* variable to store the child's pid */

    keyShm = 5678;
    keySem = 1234;

    /*
	* Create the segment.
	*/

    if ((shmid = shmget(keyShm, SHMSZ, IPC_CREAT | 0666)) < 0)
    {
	perror("shmget");
	exit(1);
    }
	
    /*

	* Now we attach the segment to our data space.
	*/

    if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
    {
	perror("shmat");
	exit(1);
    }

    if ((semid = semget(keySem, 1, IPC_CREAT | 0666)) < 0)
    {
        perror("semget");
        exit(1);
    }

    if(semctl(semid,0,SETALL,argument) < 0)
    {
        perror("semctl");
        exit(1);
    }
    sb.sem_flg  = SEM_UNDO;



    /* now create new process */
    readpid = fork();
    if (readpid >= 0) /* fork succeeded */
    {
        if (readpid == 0) /* fork() returns 0 to the read process */
        {
    	    printf("Child READ: I am the read process!\n");
            printf("Child READ: Here's my PID: %d\n", getpid());
	   /*
	   * We need to get the segment named
	   * "5678", created by the server.
	   */
 

    	   /*
	   * Locate the segment.
	   */
    	   if ((shmid = shmget(keyShm, SHMSZ, 0666)) < 0)
	   {
		perror("shmget");
        	exit(1);
    	   }
	
    	   /*
	   * Now we attach the segment to our data space.
	   */
    	   if ((shm = shmat(shmid, NULL, 0)) == (char *) -1)
	   {
        	perror("shmat");
        	exit(1);
    	   }

    	   if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	   {
        	perror("semctl");
        	exit(1);
    	   }	   
	   printf("child READ semCtlVal before lock semop = %d\n", semCtlVal);

    	   /*
	      * Lock the semaphore.
	      */

	   sb.sem_op  = -1;
	   if((semOpVal = semop(semid, &sb, nsops)) < 0)
	   {
		printf("child READ Lock fail: opResult = %d\n", semOpVal);
       		perror("semop");
        	exit(1);
    	   }
	   else printf("child READ Lock success\n");

    	   if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	   {
        	perror("semctl");
        	exit(1);
    	   }	   
	   printf("child READ semCtlVal after lock semop = %d\n", semCtlVal);
   	   /*
	   * Now read what the server put in the memory.
	   */
    	   printf("child READ: ");
	   for (s = shm; *s != (intptr_t) NULL; s++)
        	putchar(*s);
    	   putchar('\n');
	
    	   /*
	   * Finally, change the first character of the 
	   * segment to '*', indicating we have read 
	   * the segment.
	   */
//    	   *shm = '*';

   	   /*
	      * Unlock the semaphore.
	      */
 	   sb.sem_op  = 1;
	   if((semOpVal = semop(semid, &sb, nsops)) < 0)
	   {
		printf("child READ Unlock: semOpVal = %d\n", semOpVal);
        	perror("semop");
        	exit(1);
    	   }

	   else printf("child READ Unlock success\n");

    	   if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	   {
        	perror("semctl");
        	exit(1);
    	   }	   
	   printf("child READ semCtlVal after unlock semop = %d\n", semCtlVal);
    	   /*
	      * Deattach the shared memory.
	      */

	   if (shmdt(shm) == -1)
	   {
        	perror("shmat");
        	exit(1);
    	   }

	   printf("child READ: Now exit from child process\n");	
	   exit(0); /* read exits with user-provided return code */
        }

        else /* fork() returns new pid to the write process */
        {
    	    printf("\nparent WRITE: I am the write process!\n");
            printf("parent WRITE: Here's my PID: %d\n", getpid());

	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	    {
		perror("semctl");
        	exit(1);
    	    }	   
	    printf("parent WRITE semCtlVal before lock semop = %d\n", semCtlVal);
	
    	    /*
		* Lock the semaphore.
		*/
	    sb.sem_op  = -1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		printf("parent WRITE Lock: semOpVal = %d\n", semOpVal);
		perror("semop");
        	exit(1);
    	    }
	    else printf("parent WRITE Lock success\n");

    	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	    {
        	perror("semctl");
        	exit(1);
    	    }	   
	    printf("parent WRITE semCtlVal after lock semop = %d\n", semCtlVal);
	    /*
		* Now put some things into the memory for the
		* other process to read.
		*/
    	    s = shm;
	
    	    for (c = 'a'; c <= 'z'; c++)
            *s++ = c;
	    *s = (intptr_t)NULL;

    	    /*
		* Unlock the semaphore.
		*/
	    sb.sem_op  = 1;
	    if((semOpVal = semop(semid, &sb, nsops)) < 0)
	    {
		printf("parent WRITE Unlock: semOpVal = %d\n", semOpVal); 
        	perror("semop");
        	exit(1);
    	    }
	    else printf("parent WRITE Unlock success\n");

    	    if((semCtlVal = semctl(semid,0,GETVAL)) < 0)
    	    {
        	perror("semctl");
        	exit(1);
    	    }	   
	    printf("parent WRITE semCtlVal after unlock semop= %d\n", semCtlVal);
    	    /*
		* Finally, we wait until the other process 
		* changes the first character of our memory
		* to '*', indicating that it has read what 
		* we put there.
		*/
//    	    while (*shm != '*')
	    sleep(1);
	    /*

		* Deattach the shared memory.
		*/

	    if (shmdt(shm) == -1)
	    {
		perror("shmat");
		exit(1);
	    }

	    /*

		* Remove the semaphore.
		*/

	    if (semctl(semid, 0, IPC_RMID) < 0)
	    {
		perror("semctl");
		exit(1);
	    }

	   printf("parent WRITE: Now exit from parent process\n\n");
           exit(0);  /* parent server exits */       
        }
    }
    else /* fork returns -1 on failure */
    {
        perror("fork"); /* display error message */
        exit(0); 
    }
}
