#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

int setup_server_socket(int *server_fd, struct sockaddr_in *server_sock_addr, int port)
{
		// choose the type of socket we want	
	if ((*server_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Unable to create a socket file descriptor\n");
		return -1;
	}

		// setting up the properties for the connection (protocol family, ip/int, port)
	server_sock_addr->sin_family = AF_INET;         
	server_sock_addr->sin_port = htons(port);     
	server_sock_addr->sin_addr.s_addr = INADDR_ANY; 
	bzero(&(server_sock_addr->sin_zero),8); 

		// binding the file descriptor to the sockaddr struct
	if (bind(*server_fd, (struct sockaddr *) server_sock_addr, sizeof(struct sockaddr)) == -1) {
		perror("Unable to bind serverfd with server_sock_addr\n");
		return -1;
	}

		// setting up the server socket to listen, supporting up to 5 connections.
	if (listen(*server_fd, 5) == -1) {
		perror("Unable to listen\n");
		return -1;
	}

	printf("\nTCPServer Waiting for client on port %d\n", port);
	return 0;
}

int accept_client_socket(int server_fd, struct sockaddr_in *client_sock_addr)
{
	int client_fd;
	size_t size = sizeof(struct sockaddr_in);

	if ( (client_fd = accept(server_fd, (struct sockaddr *) client_sock_addr, &size)) == -1 )
	{
		perror("Unable to accept a new connection\n");
		return -1;
	}

	printf("\nI got a connection from (%s , %d)\n\n",
		(char *) inet_ntoa(client_sock_addr->sin_addr),
		ntohs(client_sock_addr->sin_port));

	return client_fd;
}

int setup_client_socket(int *fd, struct sockaddr_in *sock_addr,const char *ip_host, int port)
{
	struct hostent *host;
 
	host = gethostbyname(ip_host);

	if ((*fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		perror("Unable to create a socket file descriptor\n");
		return -1;
	}

	sock_addr->sin_family = AF_INET;     
	sock_addr->sin_port = htons(port);   
	sock_addr->sin_addr = *((struct in_addr *)host->h_addr);
	bzero(&(sock_addr->sin_zero),8); 

	if (connect(*fd, (struct sockaddr *)sock_addr,
                    sizeof(struct sockaddr)) == -1) 
	{
		perror("Unable to Connect");
		return -1;
	}

	return 0;
}


