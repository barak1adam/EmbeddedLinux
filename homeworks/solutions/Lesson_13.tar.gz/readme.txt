Hi,

Alon from Real Time Group


Hey, listen, here and there I added a few notes to explain stuff i've been doin' there.

There should be more comments, I know, I just don't have the time for that.
Your responsibility to get into the bottom of this.

I've tried to make it as simple as I can, while solving the exercise, 
and also took care of stdout as easy and aligned as possible.

It uses a little bit of threads, you can use 127.0.0.1 for local host in this fasion:

	./a.out 5000 127.0.0.1 5000

It fully simplifies the initialization process for sockets in TCP mode,
and also demonstraits the way clients sockets and server sockets usualy defined and behave.


I recommend reading the sock.h header first to see the objects I'm using,
Then get into the code (in main for example).


good luck.

