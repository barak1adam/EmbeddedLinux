#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <pthread.h>


#include "sock.h"


#define PRINT_STATUS(VAR_STATUS, TITLE) fprintf ( (VAR_STATUS != -1) ? (stdout) : (stderr), TITLE, (VAR_STATUS != -1) ? ("OK") : ("FAILED") );


sock_in  in;   // contains fd and sockaddr_in for server side (for server and client connection)
sock_out out;  // contains fd and sockaddr_in for client side (for client connection only)
               // sock_in and sock_out are structs for this demo only, read more in the header file


int  local_port;
char remote_ip_host[30];
int  remote_port;


char stdin_buff[100] = {0};
char s_out_buff[100] = {0};
char s_in_buff [100] = {0};



int check_params(int argc, char **argv);

void * init_server(void *p);
void * init_client(void *p);

void * send_func(void *p);
void  *recv_func(void *p);

int main(int argc, char **argv)
{
	pthread_t init_server_thread_id;
	pthread_t init_client_thread_id;

	pthread_t send_thread_id;
	pthread_t recv_thread_id;

	int params_flag, init_server_flag, init_client_flag, exit_flag = 0;


		// checking main parameters
	if ( (params_flag = check_params(argc, argv)) != 0 )
		return -1;



		// init server
	pthread_create(&init_server_thread_id, NULL, init_server, NULL);
	sleep(1);
		// init client
	pthread_create(&init_client_thread_id, NULL, init_client, NULL);
	sleep(2);



		// check server
	pthread_join(init_server_thread_id, (void *) &init_server_flag);
	PRINT_STATUS(init_server_flag, "init server: %s\n")

		// check client
	pthread_join(init_client_thread_id, (void *) &init_client_flag);
	PRINT_STATUS(init_client_flag, "init client: %s\n");

	printf("\n\n");

		// beginning send_func and recv_func
	pthread_create(&send_thread_id, NULL, send_func, NULL);
	pthread_create(&recv_thread_id, NULL, recv_func, NULL);

		// input from stdin
	while (!exit_flag)
	{
		sleep(2);

			// input from stdin
		printf("\n\nplease input a string ('quit' to end program): \n");
		scanf("%s", stdin_buff);

		if (strcmp(stdin_buff, "quit") == 0)
		{
			exit_flag = 1;
		}
	}

		// ending gracefully
	printf("\n\nending gracefully \n\tkilling threads..\n");
	pthread_cancel(send_thread_id);
	pthread_cancel(recv_thread_id);

	printf("\tclosing sockets..\n");
	close(out.fd);
	close(in.client_fd);
	close(in.server_fd);

	printf("ended\n\n");

	return 0;
}

int check_params(int argc, char **argv)
{
	if (argc == 1) // no parameters at all
	{
		printf("usage: %s <local port> <remote ip> <remote port>\n", argv[0]);
		printf("examp: %s 5000 192.168.0.10 5000\n", argv[0]);

		return -1;
	}
	else if (argc != 4) // incorrect number of parameters
	{
		printf("usage: %s <local port> <remote ip> <remote port>\n", argv[0]);
		printf("examp: %s 5000 192.168.0.10 5000\n", argv[0]);

		perror("error: wrong number of parameters, read usage ..\n\n");		
		return -1;
	}
	else // argc == 4, correct number of parameters
	{
		local_port = atoi(argv[1]);
		strcpy(remote_ip_host, argv[2]);
		remote_port = atoi(argv[3]);

		if (local_port >= 1024 && remote_port >= 1024) // checking for known ports
		{
			printf("\nlocal  port = %d\nremote host = %s\nremote port = %d\n\n", local_port, remote_ip_host, remote_port);
			return 0;
		}		
		else
		{
			printf("usage: %s <local port> <remote ip> <remote port>\n", argv[0]);
			printf("examp: %s 5000 192.168.0.10 5000\n", argv[0]);

			perror("error: incorrect parameters value, read usage ..\n\n");
			return -1;
		}
	}

}

void * init_server(void *p)
{
		// creates a server socket, listenning ...
	setup_server_socket(&in.server_fd, &in.server_sock_addr, local_port);

		// creates a client socket from the server, there can be more then one ..
	in.client_fd = accept_client_socket(in.server_fd, &in.client_sock_addr);
}

void * init_client(void *p)
{
		// creates a client socket that initiates a connection.
	setup_client_socket(&out.fd, &out.sock_addr, remote_ip_host, remote_port);
}


void * send_func(void *p)
{
	printf("send_func is called\n\n");

	while (1)
	{
		if (strcmp(stdin_buff, s_out_buff) == 0)
		{
			sleep(1);

			continue;
		}
		else
		{
			strcpy(s_out_buff, stdin_buff);
			send(out.fd,s_out_buff,strlen(s_out_buff), 0);
			
			printf("\nsend_func: sending '%s'", s_out_buff);

			continue;
		}
	}
}


void * recv_func(void *p)
{
	printf("recv_func is called\n\n");

	while(1)
	{
		if (strcmp(s_in_buff, stdin_buff) == 0)
		{
			if (strcmp(s_in_buff, s_out_buff) == 0)
			{
				sleep(1);

				continue;	
			}
			else
			{
				strcpy(s_out_buff, s_in_buff);

				printf("\nrecv_func: receiving '%s', moving to output buffer", s_out_buff);

				continue;
			}
		}
		else
		{
			int bytes_recieved = recv(in.client_fd,s_in_buff,1024,0);
              		s_in_buff[bytes_recieved] = '\0';
			
			printf("\nrecv_func: receiving '%s'", s_in_buff);

			continue;
		}
	}
}

