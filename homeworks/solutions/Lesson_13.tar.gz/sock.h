
#ifndef SOCK_H
#define SOCK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


/*
	In this case we have created two forms of sockets, one for client side, and one for server side.

	The client side always tries to connect to the server, the server side always listens to connections from one or more clients.

	The sock_in struct demonstrate the server side activity, which listens to new connections.
	generally there would be more then one client created from the server socket, but in this program, there will be only one.

	the sock_out struct demonstrate the client side activity, which only connects to a server.
*/

// a server side connection(s) example
typedef struct {
	int server_fd;	
	struct sockaddr_in server_sock_addr;
	int client_fd;
	struct sockaddr_in client_sock_addr;
} sock_in;

// a client side connection example
typedef struct {
	int fd;
	struct sockaddr_in sock_addr;
} sock_out;


int setup_server_socket(int *server_fd, struct sockaddr_in *server_sock_addr, int port);
int accept_client_socket(int server_fd, struct sockaddr_in *client_sock_addr);

int setup_client_socket(int *fd, struct sockaddr_in *sock_addr,const char *ip_host, int port);

#endif
