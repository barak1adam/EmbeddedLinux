#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

pthread_mutex_t mutexid1, mutexid2;
void thread_func1(void);
void thread_func2(void);

void main()
{

  pthread_mutex_init(&mutexid1,NULL);
  pthread_mutex_init(&mutexid2,NULL);
  pthread_t threadid1, threadid2;

  pthread_create(&threadid1,NULL,&thread_func1,NULL);
  pthread_create(&threadid2,NULL,&thread_func2,NULL);

  pthread_join(threadid1,NULL);
  pthread_join(threadid2,NULL);

  pthread_mutex_destroy(&mutexid1);
  pthread_mutex_destroy(&mutexid2);
}

void thread_func1(void)
{
  printf("Trying lock mutex 1-1\n");
  pthread_mutex_lock(&mutexid1);
  sleep(1);
  printf("Trying lock mutex 2-1\n");
  /*pthread_mutex_lock(&mutexid2);*/
  while(pthread_mutex_trylock(&mutexid2) != 0) /*  try-lock solution  */
  {
    sleep(1);
    printf("Unlock mutex 1-1\n");
    pthread_mutex_unlock(&mutexid1);
  }
  printf("Unlock mutex 1-2\n");
  pthread_mutex_unlock(&mutexid2);
  printf("End thread 1\n");
}

void thread_func2(void)
{
/*  Deadlock conditions
  printf("Trying lock mutex 2-2\n");
  pthread_mutex_lock(&mutexid2);
  sleep(1);
  printf("Trying lock mutex 1-2\n");
  pthread_mutex_lock(&mutexid1);

  pthread_mutex_unlock(&mutexid1);
  pthread_mutex_unlock(&mutexid2);
  printf("End thread 2\n");
 */
 /* Non-deadlock programming
  printf("Trying lock mutex 1-2\n");
  pthread_mutex_lock(&mutexid1);
  sleep(1);
  printf("Trying lock mutex 2-2\n");
  pthread_mutex_lock(&mutexid2);

  pthread_mutex_unlock(&mutexid1);
  pthread_mutex_unlock(&mutexid2);
  printf("End thread 2\n");
 */
/*  Try-lock solution   */
  printf("Trying lock mutex 2-2\n");
  pthread_mutex_lock(&mutexid2);
  sleep(1);
  printf("Trying lock mutex 1-2\n");
  while(pthread_mutex_trylock(&mutexid1) != 0)
  {
      sleep(1);
      printf("Unlock mutex 2-2\n");
      pthread_mutex_unlock(&mutexid2);
  }
  printf("Unlock mutex 2-1\n");
  pthread_mutex_unlock(&mutexid1);
  printf("End thread 2\n");

}
