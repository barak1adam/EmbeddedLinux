#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

pthread_mutex_t mutexid;
void thread_func(void);

typedef struct ThreadInfo
{
  pid_t ProcID;
  pthread_t ThreadID;
  time_t rawtime;
} ThreadRunInfo;
ThreadRunInfo ThreadRun;

void main()
{
  pthread_t Threads[3];
  int i;

  pthread_mutex_init(&mutexid,NULL);

  for(i = 0; i< 3; i++)
      pthread_create(&Threads[i],NULL,&thread_func,NULL);

  for(i = 0; i< 3; i++)
    pthread_join(Threads[i],NULL);

  pthread_mutex_destroy(&mutexid);
}

void thread_func()
{
  struct tm * timeinfo;

  pthread_mutex_lock(&mutexid);
  sleep(2);

  ThreadRun.ProcID = getpid();
  ThreadRun.ThreadID = pthread_self();
  time(&ThreadRun.rawtime);

  printf("Process ID: %d\n",(int)ThreadRun.ProcID);
  printf("Thread Id: %d\n",(int)ThreadRun.ThreadID);
  timeinfo = localtime(&ThreadRun.rawtime);
  printf("Running time: %s\n", asctime(timeinfo));

  pthread_mutex_unlock(&mutexid);

}
