compile:

gcc server.c chat.c -o server
gcc client.c chat.c -o client

run on server side:
./server

run on client side, no arguments - connects to 127.0.0.1
./client    

run on client side, connect to IP or host name
./client (<ip or host name>)
