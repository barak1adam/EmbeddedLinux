#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <netdb.h> //hostent
#include "chat.h"
#include "client.h"


int main(int argc,char * argv[])
{
  //server IP is taken from program arguments
   char server_ip_str[MAX_IP_LEN];
   if (argc>1)
     strcpy(server_ip_str,argv[1]);
   else
     strcpy(server_ip_str,"127.0.0.1");//default IP is 127.0.0.1   
  uint32_t server_ip=ipstr2n(server_ip_str);
  if (server_ip==0)//if program argument is not an IP
  {
     server_ip=HostName2IP(server_ip_str);//find IP address
     if (server_ip==0)
     {
        printf("Incorrect ip:%s\n\r",server_ip_str);
       return 1;
     }
     ipn2str(server_ip,server_ip_str);
  }  
  UserConv UserConvs[MAX_CONV];//conversations, can talk to 10 users max.
  memset(UserConvs,0,MAX_CONV*sizeof(UserConv));
  uint32_t i;
  for(i=0;i<MAX_CONV;i++) //zeroize conversations
  {
    UserConvs[i].master_socket=-1;
    UserConvs[i].client_socket=-1;
  }
  FilePtr * fileList=NULL;//list of received files

  //buffer for console input
  char input_buffer[MAX_MSG_BUF+1];
  ClearString(input_buffer,MAX_MSG_BUF+1);

  //buffer for network messages
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);

  //login username
  char username[MAX_USERNAME+1];
  ClearString(username,MAX_USERNAME+1);

  fd_set readfds;//set of sockets
  int valread;//message bytes read
  
  //socket for main server
  int main_socket=-1;
  PrintCmdMenu(main_socket);//menu
  while(TRUE)
  {
      //get activity from console or network connections
      if (!GetActivity(main_socket,UserConvs,&readfds)) break;
     
      if (FD_ISSET(0,&readfds))//activity at console
      {
        read(0,input_buffer,MAX_MSG_BUF*sizeof(char));//read user command
        ClearEndOfString(input_buffer);
        //process user command
        if (!CLProcessInput(input_buffer, &main_socket, UserConvs,username,&readfds,server_ip_str )) break;
      }
      else if ((main_socket>0)&&(FD_ISSET(main_socket,&readfds)))//activity at main server connection
      {
         valread=my_recv(main_socket,buffer,MAX_MSG_BUF);//receive data from main server
         //process it
         if (!CLProcessMessage(-1,&main_socket,buffer,valread,UserConvs,username,&readfds,&fileList)) break;
      } 
      else
      {
        for(i=0;i<MAX_CONV;i++)//if there is any activity from users connections
        {
          //activity at master socket means connecting a client to it
          if ((UserConvs[i].master_socket>0)&&(FD_ISSET(UserConvs[i].master_socket,&readfds))&&(UserConvs[i].client_socket<0))
              UserConvs[i].client_socket=AcceptClient(UserConvs[i].master_socket,&readfds);
          //activity at client socket means getting data
          else if ((UserConvs[i].client_socket>0)&&(FD_ISSET(UserConvs[i].client_socket,&readfds)))
          {
             valread=my_recv(UserConvs[i].client_socket,buffer,MAX_MSG_BUF);//receive data from user connection
             if (!CLProcessMessage(i,&main_socket,buffer,valread,UserConvs,username,&readfds,&fileList)) break;//process it
          }
        }
      }
  }
  
  disconnect(&main_socket,UserConvs,&readfds);//disconnect from all users and main server
  FreeFileList(&fileList);//free list of received files
}

//free list of received files
void FreeFileList(FilePtr ** fileList)
{
  if (fileList==NULL) return;
  FilePtr * ptr=*fileList;
  FilePtr * p2=NULL;
  while(ptr!=NULL)
  {
    p2=ptr->next;
    ptr->next=NULL;
    if (ptr->data.parts!=NULL)
    {
       free(ptr->data.parts);
       ptr->data.parts=NULL;
    }
    if (ptr->data.data!=NULL)
    {
      free(ptr->data.data);
      ptr->data.data=NULL;
    }
    free(ptr);
    ptr=p2;
  }
  
}

//index of user command in commands array
int GetUserCommandNo(char * cmdstr)
{
  return IndexOfStrArray(cmdstr,UserCommands,MAX_UC);
}

//get an activity from console, main server or user connections
uint8_t GetActivity(int main_socket,UserConv * UserConvs,fd_set * readfds)
{
   int max_sd=0;
   FD_ZERO(readfds);  
   FD_SET(0,readfds);//input
   if (main_socket>0)
   {
     FD_SET(main_socket,readfds);
     max_sd=main_socket;
   }
   int i;
   for(i=0;i<MAX_CONV;i++)
   {
     if (UserConvs[i].master_socket>0)
     {
       FD_SET(UserConvs[i].master_socket,readfds);
       if (max_sd<UserConvs[i].master_socket) max_sd=UserConvs[i].master_socket;
     }
     if (UserConvs[i].client_socket>0)
     {
       FD_SET(UserConvs[i].client_socket,readfds);
       if (max_sd<UserConvs[i].client_socket) max_sd=UserConvs[i].client_socket;
     }
   }
     
   int activity = select( max_sd + 1 , readfds , NULL , NULL , NULL);
   if ((activity < 0) && (errno!=EINTR)) 
   {
      printf("select error\n");
      return FALSE;
   }
   return TRUE;
}

//zeroize an entry in conversations array
void ClearEntry(int userIndex,UserConv * UserConvs,fd_set * readfds)
{
   FreeSocket(&UserConvs[userIndex].client_socket,readfds);
   FreeSocket(&UserConvs[userIndex].master_socket,readfds);
   ClearString(UserConvs[userIndex].username,MAX_USERNAME+1);
}

//disconnect from main server and all users
void disconnect(int * main_socket,UserConv * UserConvs,fd_set * readfds)
{
  FreeSocket(main_socket,readfds);
  int i;
  for(i=0;i<MAX_CONV;i++)
    ClearEntry(i,UserConvs,readfds);
}

//connect as server to an address
int ConnectAsServer(char * ip_str,uint16_t port,fd_set * readfds)
{
    printf("Connecting as server to %s:%d...\n\r",ip_str,port);
    
    int  sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock<=0) 
    {
       perror("Could not create socket");
       return -1;
    }
    int optval = TRUE; 
 
    if (setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int)) == -1) 
    {
      perror("setsockopt reuse address") ;
      return -1;
    }
 
    struct sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr=inet_addr(ip_str);
    address.sin_port=port;
   
    if (bind(sock, (struct sockaddr *)&address, sizeof(address))<0) 
    {
       perror("bind failed");
       return -1;
    }
       
    if (listen(sock, 3) < 0)
    {
       perror("listen");
       return -1;
    }

    printf("Listener on port %d \n\r", port);
    FD_SET(sock,readfds);
    printf("Connected as server\n\r");
    return sock;
}

//connect as client to an address
int ConnectAsClient(char * ip_str,uint16_t port,fd_set * readfds)
{
   struct sockaddr_in address;
   
   // create socket
   int sock=socket(AF_INET,SOCK_STREAM,0);
   if (sock <= 0)
   {
      perror("Could not create socket");
      return -1;
   }
  
   printf("Socket created\n\r");
   
   address.sin_family = AF_INET;
   address.sin_addr.s_addr=inet_addr(ip_str);
   address.sin_port=port;
   printf("Connecting as client to %s:%d socket %d...\n\r",ip_str,port,sock);
 
   if (connect(sock,(struct sockaddr*)&address,sizeof(address))<0)
   {
     char reply[256];
     sprintf(reply,"Connect failed to socket %d",sock);
     perror(reply);
     FreeSocket(&sock,readfds);
   }
   FD_SET(sock,readfds);
   printf("Connected as client\n\r");
   return sock;
}

//add conversation in which current IP is connected as server
uint8_t AddServerConnection(char * username,uint32_t ip,uint16_t port,UserConv * UserConvs,fd_set * readfds)
{
  char ip_str[MAX_IP_LEN];
  if (!ipn2str(ip,ip_str)) return FALSE;
  int sock=ConnectAsServer(ip_str,port,readfds);
  if (sock<0) return FALSE;
  int i;
  for(i=0;i<MAX_CONV;i++)
  {
    if ((UserConvs[i].master_socket<0)&&(UserConvs[i].client_socket<0))
    {
      strcpy(UserConvs[i].username,username);
      UserConvs[i].master_socket=sock;
      return TRUE;
    }
  }
  return FALSE;
}

//add conversation in which current IP is connected as client
uint8_t AddClientConnection(char * username,uint32_t ip,uint16_t port,UserConv * UserConvs,fd_set * readfds)
{
  char ip_str[MAX_IP_LEN];
  ipn2str(ip,ip_str);
  int sock=ConnectAsClient(ip_str,port,readfds);
  if (sock<0) return FALSE;
  int i;
  for(i=0;i<MAX_CONV;i++)
  {
    if ((UserConvs[i].master_socket<0)&&(UserConvs[i].client_socket<0))
    {
      strcpy(UserConvs[i].username,username);
      UserConvs[i].client_socket=sock;
      return TRUE;
    }
  }
  return FALSE;
}

//accept client connection to server socket
int AcceptClient(int server_socket,fd_set * readfds)
{
    struct sockaddr_in client;
    socklen_t c=sizeof(client);
    int client_socket = accept(server_socket, (struct sockaddr *)&client, &c);
    if (client_socket < 0)
    {
       perror("accept failed");
       return -1;
    }
    FD_SET(client_socket,readfds);
    printf("Accepted a client\n\r");
    return client_socket;
}

//whether user command is enabled with current state of connection to main server
uint8_t IsCommandNoEnabled(int nCmd,int main_socket)
{
  return ((main_socket<0)&&(UCmdsEnabled[nCmd]!=1)||(main_socket>=0)&&(UCmdsEnabled[nCmd]>0));
}

//print commands menu
void PrintCmdMenu(int main_socket)
{
  int i;
  printf("You are %s connected to the server, here are commands available:\n",(main_socket<0)?"not":"");
  for(i=0;i<MAX_UC;i++)
   if(IsCommandNoEnabled(i,main_socket))
     printf("%s %s\n\r",UserCommands[i],UserParams[i]);
 
}

//find user index in conversations array by username
int FindUser(const char * aUsername,UserConv * convs)
{
  int i;
  for(i=0;i<MAX_CONV;i++)
    if (StrEqual(convs[i].username,aUsername))
      return i;
  return -1;
}

//print list of currently connected users
void PrintOnlineUsers(UserConv * convs)
{
  if (convs==NULL) return;
  int i;
  printf("Online users:\n\r");
  for(i=0;i<MAX_CONV;i++)
    if ((convs[i].master_socket>0)||(convs[i].client_socket>0))
      printf("%s\n\r",(strlen(convs[i].username)>0)?convs[i].username:"Unknown user");
}

//process console input
uint8_t CLProcessInput(char * input_buffer, int * main_socket, UserConv * UserConvs,char * username, fd_set * readfds,char * server_ip_str )
{
  uint32_t wlen[3];
  uint32_t wstart[3];
  uint32_t nWords=CountWords(input_buffer,wstart,wlen);//til 3 words in command line
  if (nWords==0) 
  {
    ClearString(input_buffer,MAX_MSG_BUF+1);
    return TRUE;
  }
  char cmdstr[20];
  ClearString(cmdstr,20);
  strncpy(cmdstr,input_buffer+wstart[0],wlen[0]);//get a command from command line
  int nCommand=GetUserCommandNo(cmdstr);//get coommand index
  if (nCommand<0)//if there is no such command - exit
  {
     printf("Could not decode command %s\n\r",cmdstr);
     ClearString(input_buffer,MAX_MSG_BUF+1);
     return TRUE;
  }
  if (!IsCommandNoEnabled(nCommand,*main_socket))//if the command is not enabled - exit
  {
    printf("Command %s is not allowed now\n\r",cmdstr);
    ClearString(input_buffer,MAX_MSG_BUF+1);
    return TRUE;
  }
  if (nWords-1<UCmdsParams[nCommand])//check no. of parameters
  {
    printf("Not enough parameters\n\r");
    ClearString(input_buffer,MAX_MSG_BUF+1);
    return TRUE;
  }
  char wrd1[MAX_MSG_BUF+1];//1-st parameter
  ClearString(wrd1,MAX_MSG_BUF+1);
  if (nWords>1)
    strncpy(wrd1,input_buffer+wstart[1],wlen[1]);
  char wrd2[MAX_MSG_BUF+1];//2-nd parameter
  ClearString(wrd2,MAX_MSG_BUF+1);
  if (nWords>2)
    strncpy(wrd2,input_buffer+wstart[2],wlen[2]);  
  uint8_t ret=TRUE;
  uint8_t ok=TRUE;
  int userIndex=-1;
  int i;
  char cmd;
  int sock=-1;
  int ulen,pwdlen;
  //check username
  switch(nCommand)
  {
    case UCN_ADDC:
    case UCN_DELC:
    case UCN_LOGIN:
    case UCN_SIGNUP:
    case UCN_HANGUP: 
    case UCN_CALL:
    case UCN_ANSWER:
    case UCN_REJECT:
    case UCN_SENDMSG:
    case UCN_SENDFILE:
    {
      ulen=strlen(wrd1);
      if (ulen<=0)
      {
        printf("Username cannot be empty\n\r");
        ClearString(input_buffer,MAX_MSG_BUF+1);
        return TRUE;
      }
      if (ulen>MAX_USERNAME)
      {
         printf("Username too long\n\r");
         ClearString(input_buffer,MAX_MSG_BUF+1);
         return TRUE;
      }
      if ((nCommand!=UCN_LOGIN)&&(nCommand!=UCN_SIGNUP))
      {
       if (StrEqual(username,wrd1))
       {
         printf("%s is you\n\r",wrd1);
         ClearString(input_buffer,MAX_MSG_BUF+1);
         return TRUE;
       }
       userIndex=FindUser(wrd1,UserConvs);
      }
    };break;
  }

  switch(nCommand)
  {
     case UCN_CALL:
     case UCN_ANSWER:
     case UCN_REJECT:
     { 
          if (userIndex>=0)
          {
            printf("Already talking with %s\n\r",wrd1); 
            ClearString(input_buffer,MAX_MSG_BUF+1);
            return TRUE;
          }
     };break;
     case UCN_SENDMSG:
     case UCN_SENDFILE:
     {
        sock=(userIndex<0)?(*main_socket):UserConvs[userIndex].client_socket;
        if (sock<=0)
        {
          printf("Cannot send\n\r");
          ClearString(input_buffer,MAX_MSG_BUF+1);
          return TRUE;
        }
     };break;
  }
  
  switch(nCommand)//check password
  {
     case UCN_CHGPWD:
     case UCN_LOGIN:
     case UCN_SIGNUP:
     {
        pwdlen=(nCommand==UCN_CHGPWD)?strlen(wrd1):strlen(wrd2);//check password
        if (pwdlen>=256)
        {
          printf("Password too long\n\r");
          ClearString(input_buffer,MAX_MSG_BUF+1);
          return TRUE;
        }
     };break;
  };

  switch(nCommand)//command index
  {
   case UCN_QUIT://quit program
             {
               printf("Quitting...\n\r");
               ret=FALSE;
             };break;
   case UCN_DELC:SendSimpleMessage(*main_socket,wrd1,CMD_DELCONTACT);break;//delete contact
   case UCN_ADDC:SendSimpleMessage(*main_socket,wrd1,CMD_ADDCONTACT);break; //add contact 
   case UCN_SHOWC:SendSimpleMessage(*main_socket,username,CMD_SHOWCONTACTS);break;//show contact list   
   case UCN_ABOUT:PrintAbout();break;//about the program          
   case UCN_LIST:PrintOnlineUsers(UserConvs);break;//who is online
   case UCN_MENU:PrintCmdMenu(*main_socket);break;//print menu
   case UCN_LOGOUT://disconnect froom main server, but don't quit the program
            {
              disconnect(main_socket,UserConvs,readfds);
              PrintCmdMenu(*main_socket);
            };break;
   case UCN_LOGIN://log in as existent user
   case UCN_SIGNUP://sign up as new user
         { //connect to main server
           *main_socket=ConnectAsClient(server_ip_str,PORT,readfds);
           if (*main_socket<0) 
             printf("Could not connect to server\n\r");
           else
           {       
             cmd=(nCommand==UCN_LOGIN)?CMD_LOGIN:CMD_SIGNUP;//send login or signup message to main server
             ret=SendString(*main_socket,wrd1,wrd2,cmd,time(NULL));
             if (ret) 
                printf("%s as %s %s requested\n\r",(nCommand==UCN_LOGIN)?"Login":"Sign up",wrd1,(ret)?"":"not");
             else
               FreeSocket(main_socket,readfds);  
           }  
        };break;
        case UCN_HANGUP://disconnect from user
         {
            if (userIndex<0)
              printf("Was not connected to %s\n",wrd1);
            else
            {  
              printf("Disconnecting from %s...\n\r",wrd1);
              SendSimpleMessage(UserConvs[userIndex].client_socket,username,CMD_HANGUP);
              ClearEntry(userIndex,UserConvs,readfds);
             }
         };break;
       case UCN_CHGPWD: //change password
         {
            //send change password message to main server
             ok=SendString(*main_socket,username,wrd1,CMD_CHGPWD,time(NULL));
             printf("%s password\n\r",(ok)?"Changed":"Cannot change");
        };break;
     case UCN_CALL://call user
       {
          ok = SendSimpleMessage(*main_socket,wrd1,CMD_CALL);//send call message to main server
          printf("%s %s\n\r",(ok)?"Calling":"Cannot call",wrd1);
       };break;
     case UCN_ANSWER://answer call from user
      {
        ok = SendSimpleMessage(*main_socket,wrd1,CMD_ANSWER);//send answer message to main server
        printf("%s call from %s\n\r",(ok)?"Answering":"Cannot answer",wrd1);
      };break;
     case UCN_REJECT://reject call from user
       {  
         ok = SendSimpleMessage(*main_socket,wrd1,CMD_REJECT);//reject message to main server
         printf("%s call from %s\n\r",(ok)?"Rejecting":"Cannot reject",wrd1);
      };break;
    
  case UCN_SENDMSG://send text message to user
   {
       char cmsg[MAX_MSG_BUF+1];
       ClearString(cmsg,MAX_MSG_BUF+1);
       uint32_t i;
       uint32_t l=strlen(input_buffer);
       for(i=wstart[2];i<l;i++)
         cmsg[i-wstart[2]]=input_buffer[i];
       ok=SendString(sock,(userIndex<0)?wrd1:username,cmsg,CMD_MSG,time(NULL));
       printf("%s message\n\r",(ok)?"Sending":"Cannot send");  
   };break;
   case UCN_SENDFILE://send file to user
    {
      if (strlen(wrd2)>=256)//check filename
        printf("File name %s too long\n\r",wrd2);
     else if (!FileExists(wrd2))//check file
          printf("File %s does not exist\n\r",wrd2);
     else
     { 
//send file to user directly if connected, via main server if not
        ok=SendFile(sock,(userIndex<0)?wrd1:username,wrd2);
        printf("%s file %s to %s\n\r",(ok)?"Sending":"Cannot send",wrd2,wrd1); 
     }  
  };break;

 }
 ClearString(input_buffer,MAX_MSG_BUF+1);
 return ret;
}

void PrintContacts(uint8_t * buffer,UserConv * convs)
{
  if (buffer==NULL)
  {
    printf("No contact list\n\r");
    return;
  }
  char contacts[MAX_CONTACTS][MAX_USERNAME+1];
  uint8_t online[MAX_CONTACTS];
  uint16_t nContacts=ExtractContacts(buffer,contacts,online);
  if (nContacts==0)
  {
    printf("Your contact list is empty\n\r");
    return;
  }
  printf("Your contact list is:\n\r==========\n\r");
  uint16_t i;
  int userIndex;
  for(i=0;i<nContacts;i++)
  {
     printf("%s",contacts[i]);
     userIndex=FindUser(contacts[i],convs);
     if (userIndex<0)
     {
       if (online[i])
         printf(" online");
     }
     else
       printf(" connected");
     printf("\n\r");   
  }
}

//process message from main server or user connection
uint8_t CLProcessMessage(int userIndex,int * main_socket,uint8_t * buffer,int valread,UserConv * convs,char * username,fd_set * readfds,FilePtr ** fileList)
{
  if (*main_socket<0) return FALSE;
  if (valread<0)//error receiving message
  {
    perror("recv");
    return TRUE;
  }
  if (valread==0) //0 bytes received means peer or server that disconnected
  {
    printf("%s disconnected\n\r",(userIndex<0)?"Server":"Peer");
    if (userIndex<0)
    {
      disconnect(main_socket,convs,readfds);
      PrintCmdMenu(*main_socket);
    }
    else
    {
       printf("User %s hangs receiver up\n\r",convs[userIndex].username);
       ClearEntry(userIndex,convs,readfds);
    }
    return TRUE;
  }
  char command;
  char aUsername[MAX_USERNAME+1];
  time_t mtime;
  char filename[256];
  //get message from received data
  uint8_t * msg=DecodeMessage(buffer,&command,aUsername,&mtime);
  if (msg==NULL)
  {
     printf("Cannot decode message\n\r");
     return TRUE;
  }
   uint8_t ret=TRUE;
   uint32_t partno=0;
   uint32_t ip=0;
   uint16_t port=0;
   uint32_t filelen=0;
   char orig_filename[256];
   char ip_str[MAX_IP_LEN];
   uint8_t ok=TRUE;
   struct tm * lt=localtime(&mtime);
   switch(command)//message type
   {
      case CMD_OK_ADDC:printf("%s added successfully to contact list\n\r",aUsername);break;
      case CMD_ERR_ADDC:printf("Could not add %s to contact list\n\r",aUsername);break;
      case CMD_OK_DELC:printf("%s deleted successfully from contact list\n\r",aUsername);break;
      case CMD_ERR_DELC:printf("%s could not be deleted from contact list\n\r",aUsername);break;
      case CMD_ERROR_SHOWC:printf("Error showing contacts\n\r");break;
      case CMD_OK_SHOWC:PrintContacts(buffer,convs);break;
      case CMD_RECEIVED://file received
      case CMD_NOT_RECEIVED://file not received
                  {
                     char u[MAX_USERNAME+1];
                     ClearString(filename,256);
                     buf2str(filename,msg,255);
                     ClearString(u,MAX_USERNAME+1);
                     buf2str(u,msg+256,MAX_USERNAME);
                     printf("File %s %s received at %02d/%02d/%04d %02d:%02d:%02d by %s\n\r",
                       filename,(command==CMD_NOT_RECEIVED)?"not":"",
                       lt->tm_mday,lt->tm_mon+1,lt->tm_year+1900,lt->tm_hour,lt->tm_min,lt->tm_sec,u);
                  };break;
      case CMD_SERVER_DOWN://main server shuts down
                  {
                    printf("Server is down\n\r");
                    disconnect(main_socket,convs,readfds);
                    PrintCmdMenu(*main_socket);
                  };break;
    case CMD_CALL:printf("%s is calling\n\r",aUsername);break;//call from user
    case CMD_ANSWER:{ //user answers your call
                      if (SendSimpleMessage(*main_socket,aUsername,CMD_ANSWER_OK))//confirm answer
                      {
                        if(ExtractAddress(msg,&ip,&port))//get IP and port
                        {
                          if (!AddServerConnection(aUsername,ip,port,convs,readfds))//connect as server to this IP and port
                          {
                            ipn2str(ip,ip_str);
                            printf("Could not connect as server to ip=%s,port=%u\n\r",ip_str,port);
                          }
                        }
                        else
                          printf("Could not extract IP address\n\r");
                      }
                      else
                        printf("Could not confirm answer to %s\n\r",aUsername);
                    };break;
    case CMD_ANSWER_OK://answer confirmation
                 {
                    if (ExtractAddress(msg,&ip,&port))//get IP and port
                    {
                        if (!AddClientConnection(aUsername,ip,port,convs,readfds))//connect as client to that IP and port
                        {
                           ipn2str(ip,ip_str);
                           printf("Could not connect as client to ip=%s,port=%u\n\r",ip_str,port);
                        }
                    }
                    else
                       printf("Could not extract IP address\n\r");
                 };break;
    case CMD_REJECT:printf("%s rejected your call\n\r",aUsername);break;//call rejected
    case CMD_OK_LOGIN: //confirm login          
    case CMD_OK_SIGNUP://confirm sogning up
                  {
                    strcpy(username,aUsername);//get client username
                    printf("%s as %s\n\r",(command==CMD_OK_LOGIN)?"Logged in":(command==CMD_OK_SIGNUP)?"Signed up":"Connected",username);
                    PrintCmdMenu(*main_socket);//commands menu
                  };break;
    case CMD_OK_CHGPWD:printf("Password changed successfully\n\r");break; //change of password confirmation          
    case CMD_ERR_SIGNUP://error signing up
    case CMD_ERR_LOGIN://login error
                   {
                      printf("Error %s as %s\n\r",(command==CMD_ERR_LOGIN)?"logging in":"signing up",aUsername);
                      disconnect(main_socket,convs,readfds);
                      PrintCmdMenu(*main_socket);
                    };break;
    case CMD_ERR_CHGPWD:printf("Could not change password\n\r");break; //error changing password                               
    case CMD_ERR_CALL://call error
    case CMD_ERR_ANSWER:printf("Error %s %s\n\r",(command==CMD_ERR_CALL)?"calling":"answering",aUsername);break;//answering call error
    case CMD_MSG://text message
        {
           char cmsg[MAX_MSG_BUF-MAX_USERNAME-2];
           buf2str(cmsg,msg,MAX_MSG_BUF-MAX_USERNAME-2);
           printf("%s said %s at %02d/%02d/%04d %02d:%02d:%02d\n\r%s\n\r",aUsername,(userIndex<0)?"(via main server)":"",
               lt->tm_mday,lt->tm_mon+1,lt->tm_year+1900,lt->tm_hour,lt->tm_min,lt->tm_sec,cmsg);
        };break;
     case CMD_OK_MSG://text message confirmation
     case CMD_ERR_MSG:printf("Message was %s sent to %s\n\r",(command==CMD_ERR_MSG)?"not":"",aUsername);break; //text message error  
     case CMD_FILE: //small file
      {
        ClearString(orig_filename,256);
        uint8_t * buf=GetFileParams(msg,filename,&filelen);
        strcpy(orig_filename,filename);
        if (buf==NULL) 
          ok=FALSE;
        else
        {
           if (FileExists(filename))
              NewFileName(filename);
           ok = ReceiveFile(filename,buf,filelen);
           if (ok) ok=FileExists(filename);
        }
        printf("%s file %s (%d bytes) from %s %s\n\r",(ok)?"Received":"Could not receive",filename,filelen,aUsername,(userIndex<0)?"(via main server)":"");
        if ((ok)&&(strlen(orig_filename)>0))
        {
           printf("Confirmation ");
           if (!SendFileConfirmation((userIndex<0)?(*main_socket):convs[userIndex].client_socket,
              (ok)?CMD_RECEIVED:CMD_NOT_RECEIVED,
              orig_filename,aUsername,username))
             printf("not ");
           printf("sent\n\r");
        }
      };break;
     case CMD_FILEPART://part of a large file
       {
         uint32_t nPartNo=0;
         uint32_t nPartLen=0;
         uint8_t full=FALSE;
         GetFilePartParams(msg,filename,&filelen, &nPartNo,&nPartLen);
         FileRec * fileRec=FindFile(aUsername,filename,*fileList);
         if (fileRec==NULL)
            fileRec=AddFile(aUsername,filename,fileList);
         if (fileRec==NULL) 
           printf("Could not add file %s from %s to list of files\n\r",filename,username);
         else if (GetFilePart(msg,fileRec->name, &fileRec->parts, &fileRec->nParts,&nPartNo,&fileRec->len,&fileRec->data))
           full=TRUE;
         if (fileRec!=NULL)
           printf("%s file %s (%d bytes) from %s, part %d %s\n\r",(ret)?"Received":"Could not receive",fileRec->name,fileRec->len,aUsername, nPartNo+1,
                 (userIndex<0)?"(via main server)":"");
         if (full)
         {
           strcpy(orig_filename,filename);
           if (FileExists(filename))
              NewFileName(filename);
           ok=ReceiveFile(filename,fileRec->data,fileRec->len);
           if (ok) ok=FileExists(filename);
           if (ok)
           {
             RemoveFileFromList(aUsername,filename,fileList);
             printf("All file received as %s.\n\r",filename);
           }
           printf("Confirmation ");
           if (!SendFileConfirmation((userIndex<0)?(*main_socket):convs[userIndex].client_socket,
               (ok)?CMD_RECEIVED:CMD_NOT_RECEIVED,orig_filename,aUsername,username))
                printf("not ");
           printf("sent\n\r");
         }
       };break; 
     case CMD_OK_FILE://sending file confirmation
     case CMD_ERR_FILE://error sending file
       {
         uint32_t partno=buf2int32(msg);
         if (partno==0) printf("All");
         else printf("Part %u of",partno);
         printf(" file %s sent to %s\n\r",(command==CMD_ERR_FILE)?"not":"was",aUsername);
       };break; 
     case CMD_HANGUP://users hangs receiver up
       {
         int ui=FindUser(aUsername,convs);
         if (ui>=0)
         {
           ClearEntry(ui,convs,readfds);
           printf("%s hangs up\n\r",aUsername);
         }  
       };break;   
    case CMD_STOP://stop everything
       {
         printf("Shutdown command from the server\n\r");
         ret=FALSE;
       };break;   
  }
  return ret;
}

//find file in list of received files
FileRec * FindFile(char * username,char * filename,FilePtr * fileList)
{
  FilePtr * ptr=fileList;
  while(ptr!=NULL)
  {
     if ((StrEqual(ptr->data.name,filename))&&(StrEqual(ptr->data.username,username)))
       return &(ptr->data);
     ptr=ptr->next;
  }
  return NULL;
}

//remove file data from list of received files when it is fully received
void RemoveFileFromList(char * username,char * filename,FilePtr ** fileList)
{
  if (fileList==NULL) return;
  FilePtr * ptr=*fileList;
  FilePtr * p=NULL;
  while(ptr!=NULL)
  {
     if ((StrEqual(ptr->data.name,filename))&&(StrEqual(ptr->data.username,username)))
     {
       if (p==NULL)
        *fileList=ptr->next;
       else
        p->next=ptr->next;
       ptr->next=NULL;
       if (ptr->data.data!=NULL)
       {
          free(ptr->data.data);
          ptr->data.data=NULL;
       }
       if (ptr->data.parts)
       {
          free(ptr->data.parts);
          ptr->data.parts=NULL;
       }
       free(ptr);
       ptr=NULL;
       return;
     }
     p=ptr;
     ptr=ptr->next;
  }
}

//add file to received files list
FileRec * AddFile(char * username,char * filename,FilePtr ** fileList)
{
   if (fileList==NULL) return NULL;
   FilePtr * ptr=(FilePtr*)malloc(sizeof(FilePtr));
   memset(ptr,0,sizeof(FilePtr));
   ptr->data.data=NULL;
   ptr->data.parts=NULL;
   strcpy(ptr->data.name,filename);
   strcpy(ptr->data.username,username);
   ptr->next=*fileList;
   *fileList=ptr;
   return &(ptr->data);
}

