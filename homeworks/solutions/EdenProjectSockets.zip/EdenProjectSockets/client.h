#ifndef _CLIENT_H
#define _CLIENT_H

#include <inttypes.h>

#define MAX_CONV 10 //maximum no. of conversations

//user commands
#define UC_ADDC "ADDCONTACT"
#define UC_DELC "DELCONTACT"
#define UC_SHOWC "SHOWCONTACTS"
#define UC_LOGIN "LOGIN"
#define UC_SIGNUP "SIGNUP"
#define UC_LIST "LIST"
#define UC_CALL "CALL"
#define UC_ANSWER "ANSWER"
#define UC_REJECT "REJECT"
#define UC_CHGPWD "CHGPWD"
#define UC_SENDMSG "SENDMSG"
#define UC_SENDFILE "SENDFILE"
#define UC_HANGUP "DISCONNECT"
#define UC_LOGOUT "LOGOUT"
#define UC_MENU "MENU"
#define UC_ABOUT "ABOUT"
#define UC_QUIT "QUIT"

//indexes of user commands
#define UCN_ADDC   0
#define UCN_DELC   1
#define UCN_SHOWC  2
#define UCN_LOGIN  3
#define UCN_SIGNUP 4
#define UCN_LIST   5
#define UCN_CALL   6
#define UCN_ANSWER 7
#define UCN_REJECT 8
#define UCN_CHGPWD 9
#define UCN_SENDMSG 10
#define UCN_SENDFILE 11
#define UCN_HANGUP 12
#define UCN_LOGOUT 13
#define UCN_MENU  14
#define UCN_ABOUT 15
#define UCN_QUIT 16

#define MAX_UC 17 //no. of user commands

static char * UserCommands[]={UC_ADDC,UC_DELC,UC_SHOWC,UC_LOGIN,UC_SIGNUP,UC_LIST,UC_CALL,UC_ANSWER,UC_REJECT,UC_CHGPWD,UC_SENDMSG,UC_SENDFILE,UC_HANGUP,UC_LOGOUT,UC_MENU,UC_ABOUT,UC_QUIT};

//parameters for each user command
static char * UserParams[]={"<username>",//add contact
                            "<username>",//delete contact
                            "",//show contacts
                            "<username> <password>",//login
                            "<username> <password>",//sign up
                            "",//list
                            "<username>",//call
                            "<username>",//answer
                             "<username>",//reject
                            "<new password>",//change password
                            "<username> <message>",//send message
                            "<username> <filename>",//send file
                            "<username>",//hang up 
                             "",//log out
                             "",//menu
                             "",//about
                              ""};//quit

//which commands enabled: 
// 0 - enabled when disconnected from server
// 1 - enabled when connected to server
// 2 - enabled in any time
static uint8_t UCmdsEnabled[]={1,1,1,0,0,1,1,1,1,1,1,1,1,1,2,2,2};

//no. of parameters for each user command
static uint8_t UCmdsParams[]={1,1,0,2,2,0,1,1,1,1,2,2,1,0,0,0,0};

//conversation
typedef struct _userConv
{
  char username[MAX_USERNAME+1];
  int master_socket;
  int client_socket;
  uint32_t ip;
  uint16_t port;
} UserConv;

//received file data
typedef struct _fileRec
{
  char username[MAX_USERNAME+1];
  char name[256];
  uint32_t len;
  uint8_t * data;
  uint32_t * parts;
  uint32_t nParts;
} FileRec;

//files list
typedef struct _filePtr
{
  FileRec data;
  struct _filePtr * next;
} FilePtr;

void PrintContacts(uint8_t * buffer,UserConv * convs); //print contact list

void PrintOnlineUsers(UserConv * convs);//who is online

FileRec * AddFile(char * username,char * filename,FilePtr ** fileList);//add file to received list

void RemoveFileFromList(char * username,char * filename,FilePtr ** fileList);//remove flie from eceived files list

FileRec * FindFile(char * username,char * filename,FilePtr * fileList);//find file in file list

void FreeFileList(FilePtr ** fileList);

int FindUser(const char * aUsername,UserConv * convs);//find username in array of conversations

int GetUserCommandNo(char * cmdstr);//get index of user command

void ClearEntry(int userIndex,UserConv * UserConvs,fd_set * readfds);//zeroize conversation

void disconnect(int * main_socket,UserConv * UserConvs,fd_set * readfds);//disconnect all

int ConnectAsServer(char * ip_str,uint16_t port,fd_set * readfds);

int ConnectAsClient(char * ip_str,uint16_t port,fd_set * readfds);

//connect to user as server
uint8_t AddServerConnection(char * username,uint32_t ip,uint16_t port,UserConv * UserConvs,fd_set * readfds);

//connect to user as client
uint8_t AddClientConnection(char * username,uint32_t ip,uint16_t port,UserConv * UserConvs,fd_set * readfds);

//accept client connection fr master socket
int AcceptClient(int server_socket,fd_set * readfds);

//command enabled?
uint8_t IsCommandNoEnabled(int nCmd,int main_socket);

void PrintCmdMenu(int main_socket);//commands menu

//process console input
uint8_t CLProcessInput(char * input_buffer, int * main_socket, UserConv * UserConvs,char * username, fd_set * readfds,char * server_ip_str );

//process message from main server or connected user 
uint8_t CLProcessMessage(int userIndex,int * main_socket,uint8_t * buffer,int valread,UserConv * convs,char * username,fd_set * readfds,FilePtr ** fileList);
      
//where something happens in the network
uint8_t GetActivity(int main_socket,UserConv * UserConvs,fd_set * readfds);


#endif
