#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> 

#include "chat.h"
#include "server.h"
  

int main(int argc , char * argv[])
{
    if (!MakeDirectory(DBPATH)) 
    {
      printf("Could not create directory %s\n\r",DBPATH);
      return 1;
    }
    int master_socket=-1;
    
    int new_socket=-1;
    int addrlen , activity, valread , sd;
    uint16_t i;
    int max_sd;
    struct sockaddr_in address;
    user * users=NULL;
    uint16_t nClients=0;
    UserPort * userPorts=NULL;
    uint16_t nPorts=0;
    int32_t p;
    int opt=TRUE;
    uint8_t ok=TRUE;
    uint8_t buffer[MAX_MSG_BUF+1];  //data buffer
    char input_buffer[MAX_INPUT_BUF+1];
    //set of socket descriptors
    fd_set readfds;
    //create a master socket
    if( (master_socket = socket(AF_INET , SOCK_STREAM , 0)) < 0) 
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
  
    //set master socket to allow multiple connections , this is just a good habit, it will work without this
    if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )
    {
        perror("setsockopt reuse address");
        exit(EXIT_FAILURE);
    }
 
    //type of socket created
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = PORT;
      
    //bind the socket to localhost port 8888
    if (bind(master_socket, (struct sockaddr *)&address, sizeof(address))<0) 
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    printf("Listener on port %d \n", PORT);
     
    if (listen(master_socket, 3) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }
      
    addrlen = sizeof(address);
    printf("Waiting for connections...\n\r");
    char c;
    uint8_t stop;
    ClearString(input_buffer,MAX_INPUT_BUF+1);
    PrintMenu();
    while(TRUE) 
    {
        //clear the socket set
        FD_ZERO(&readfds);
        
        FD_SET(0,&readfds);//input
  
        //add master socket to set
        FD_SET(master_socket, &readfds);
        max_sd = master_socket;
        
         //add child sockets to set
        for ( i = 0 ; i < nClients ; i++) 
        {
            //socket descriptor
            sd = users[i].sock;
             
            //if valid socket descriptor then add to read list
            if(sd > 0)
                FD_SET( sd , &readfds);
             
            //highest file descriptor number, need it for the select function
            if(sd > max_sd)
                max_sd = sd;
        }
  
        //wait for an activity on one of the sockets , timeout is NULL , so wait indefinitely
        activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);
    
        if ((activity < 0) && (errno!=EINTR)) 
        {
            printf("select error\n");
            break;
        }
        
        if (FD_ISSET(0,&readfds))//input
        {
          ClearString(input_buffer,MAX_INPUT_BUF+1);
          read(0,input_buffer,MAX_INPUT_BUF);
          ClearEndOfString(input_buffer);
          if (!SRVProcessInput(input_buffer,users,nClients)) break;
        }
          
        //If something happened on the master socket , then its an incoming connection
        if (FD_ISSET(master_socket, &readfds)) 
        {
            if ((new_socket = accept(master_socket, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)
            {
                perror("accept");
                break;
            }
          
            //inform user of socket number - used in send and receive commands
            printf("New connection , socket fd is %d , ip is : %s , port : %d \n" , new_socket , inet_ntoa(address.sin_addr) ,address.sin_port);
           
            //add new socket to array of sockets
            p=AddSocket(&users,&nClients,new_socket,&address);
            printf("Adding to list of sockets as %d\n" , p);
        }
          
        //else its some IO operation on some other socket :)
       
        for (stop=FALSE,i = 0; (i < nClients)&&(!stop); i++) 
        {
            sd =users[i].sock;
            if (sd>=0)
            {  
              if (FD_ISSET( sd , &readfds)) 
              {
                //Check if it was for closing , and also read the incoming message
                valread = read( sd , buffer, MAX_MSG_BUF);
                if (valread  == 0)
                {
                    //Somebody disconnected , get his details and print
                    getpeername(sd , (struct sockaddr*)&address , (socklen_t*)&addrlen);
                    printf("Host disconnected , ip %s , port %d, username %s \n" , 
                      inet_ntoa(address.sin_addr) , address.sin_port, (strlen(users[i].username)>0)?users[i].username:"unknown");
                      
                    //Close the socket and mark as 0 in list for reuse
                    close( sd );
                    RemoveSocket(&users,i,&nClients);    
                }
                else if (valread<0)
                   perror("recv failed");
                else
                { //process client message
                   ok = SRVProcessMessage(i,users,nClients,&userPorts,&nPorts,buffer);
                   if (!ok) stop=TRUE;
                }
              }
            }
        }
        if (stop) break;
    }
    printf("Shutting down...\n\r");
    for(i=0;i<nClients;i++)
      if (users[i].sock!=0)
        SendSimpleMessage(users[i].sock,users[i].username,CMD_SERVER_DOWN);
    FreeUsers(&users,&nClients);
    FreePorts(&userPorts,&nPorts);
    return 0;
} 

//find user in array of online users
int32_t FindIndexByUserName(const char * username,user * users,uint16_t nClients)
{
  if (users==NULL) return -1;
  int32_t i;
  for(i=0;i<nClients;i++)
    if (StrEqual(username,users[i].username))
      return i;
  return -1;    
}

//free online users array
void FreeUsers(user ** users,uint16_t * nClients)
{
  if (nClients!=NULL) *nClients=0;
  if (users==NULL) return;
  if (*users==NULL) return;
  free(*users);
  *users=NULL;
}

//look for username and password in database
uint8_t FindInFile(const char * username,const char * password)
{
   
   char fn[256];
   
   MakeFileName(fn,DBPATH,DBNAME,F_END);
   FILE * fptr=fopen(fn,"rb");
   if (fptr==NULL) return FALSE;
   UserRec rec;
   uint8_t found=FALSE;
   while( (!feof(fptr))&&(!found))
   {
     fread(&rec,sizeof(UserRec),1,fptr);
     if (password==NULL)
     {
       if (StrEqual(username,rec.username)) found=TRUE;
     }
     else
     {
       if ((StrEqual(username,rec.username))&&(strcmp(password,rec.password)==0))
         found=TRUE;
     }  
   }
   fclose(fptr);
   return found;
}

//change password in database for an user
uint8_t ChangePassword(const char * username,const char * password)
{
  char fDB[256];
  MakeFileName(fDB,DBPATH,DBNAME,F_END);
  FILE * fIn=fopen(fDB,"rb");
  if (fIn==NULL) return FALSE;
  char fTemp[256];
  MakeFileName(fTemp,DBPATH,TEMPFN,F_END);
  FILE * fOut=fopen(fTemp,"wb");
  if (fOut==NULL)
  {
    fclose(fIn);
    return FALSE;
  }
  UserRec rec;
  uint8_t found=FALSE;
  while(!feof(fIn))
  {
     fread(&rec,sizeof(UserRec),1,fIn);
     if (StrEqual(username,rec.username))
     {
       strcpy(rec.password,password);
       found=TRUE;
     }
     fwrite(&rec,sizeof(UserRec),1,fOut);
  }
  fclose(fOut);
  fclose(fIn);
  if (!found)
  {
    RemoveFile(TEMPFN);
    return FALSE;
  }
  fIn=fopen(fTemp,"rb");
  if (fIn==NULL) return FALSE;
  fOut=fopen(fDB,"wb");
  if (fOut==NULL)
  {
    fclose(fIn);
    return FALSE;
  }
  fseek(fIn,0,SEEK_END);
  uint32_t fsize=ftell(fIn);
  fseek(fIn,0,SEEK_SET);
  uint8_t * buffer=newBuffer(fsize);
  fread(buffer,fsize,1,fIn);
  fclose(fIn);
  fwrite(buffer,fsize,1,fOut);
  fclose(fOut);
  RemoveFile(TEMPFN);
  FreeBuffer(&buffer);
  return TRUE;
}

//check if login is correct
uint8_t chkLogin(const char * username,const char * password, user * users,uint16_t nClients)
{
   if (FindIndexByUserName(username,users,nClients)>=0) return FALSE; //look in online users array
   return FindInFile(username,password);//look in database
} 

//check if signing up is correct
uint8_t chkSignup(const char * username,const char * password,user * users,uint16_t nClients)
{
   if (FindIndexByUserName(username,users,nClients)>=0) return FALSE; //look among online users
   return (!FindInFile(username,password));//look in database
}

//add user to database
uint8_t AddUser(const char * username,const char * password)
{ 
  char fn[256];
  
  MakeFileName(fn,DBPATH,DBNAME,F_END);
  FILE * fptr=fopen(fn,"a+b");
  if (fptr==NULL) return FALSE;
  UserRec rec;
  strcpy(rec.username,username);
  strcpy(rec.password,password);
  fwrite(&rec,sizeof(UserRec),1,fptr);
  fclose (fptr);
  return TRUE;
}

//read contact list of an user
uint16_t ReadContacts(char contacts[][MAX_USERNAME+1],char * username)
{
  char fn[256];
  MakeFileName(fn,DBPATH,username,F_CNT_END);
  FILE * fptr=fopen(fn,"rb");
  if (fptr==NULL) return 0;
  fseek(fptr,0,SEEK_END);
  uint32_t bufsize=(uint32_t)ftell(fptr);
  if (bufsize==0)
  {
     fclose(fptr);
     return 0;
  }
  uint8_t * buffer=newBuffer(bufsize);
  fseek(fptr,0,SEEK_SET);
  fread(buffer,bufsize,1,fptr);
  fclose(fptr);
  uint16_t nContacts=bufsize/MAX_USERNAME;
  uint16_t i;
  for(i=0;i<nContacts;i++)
    buf2str(contacts[i],buffer+i*MAX_USERNAME,MAX_USERNAME);
  FreeBuffer(&buffer);
  return nContacts;
}

//save contact list for an user
uint8_t SaveContacts(char contacts[][MAX_USERNAME+1],uint16_t nContacts,char * username)
{
  uint8_t * buffer=NULL;
  uint32_t bufsize=nContacts*MAX_USERNAME;
  if (bufsize>0)
  {
    buffer=newBuffer(bufsize);
    memset(buffer,0,bufsize);
  }
  uint16_t i;
  for(i=0;i<nContacts;i++)
    str2buf(buffer+i*MAX_USERNAME,contacts[i]);
  char fn[256];
  MakeFileName(fn,DBPATH,username,F_CNT_END);
  FILE * fptr=fopen(fn,"wb");
  if (fptr==NULL) 
  {
    FreeBuffer(&buffer);
    return FALSE;
  }
  if (bufsize>0) 
     fwrite(buffer,bufsize,1,fptr);
  fclose(fptr);
  FreeBuffer(&buffer);
  return TRUE;
}

//find username in contact list
int FindContact(char contacts[][MAX_USERNAME+1],uint16_t nContacts,char * username)
{
  uint16_t i;
  for(i=0;i<nContacts;i++)
    if (StrEqual(contacts[i],username))
      return (int)i;
  return -1;     
}

//add contact to contacts list
uint8_t AddContact(user * users, uint16_t userIndex,char * aUsername,uint16_t nClients)
{
   if (userIndex>=nClients) return FALSE;
   if (!FindInFile(aUsername,NULL)) return FALSE;
   char contacts[MAX_CONTACTS][MAX_USERNAME+1];
   uint16_t nContacts=ReadContacts(contacts,users[userIndex].username);
   if (nContacts>=MAX_CONTACTS) return FALSE;
   int nContactIndex=FindContact(contacts,nContacts,aUsername);
   if (nContactIndex>=0) return FALSE;
   memset(contacts[nContacts],0,(MAX_USERNAME+1)*sizeof(char));
   strcpy(contacts[nContacts],aUsername);
   nContacts++;
   return SaveContacts(contacts,nContacts,users[userIndex].username);
}

//delete contact from contact list
uint8_t DelContact(user * users,uint16_t userIndex,char * aUsername,uint16_t nClients)
{
  if (userIndex>=nClients) return FALSE;
  char contacts[MAX_CONTACTS][MAX_USERNAME+1];
  uint16_t nContacts=ReadContacts(contacts,users[userIndex].username);
  if (nContacts==0) return FALSE;
  int nContactIndex=FindContact(contacts,nContacts,aUsername);
  if (nContactIndex<0) return FALSE;
  int i;
  for(i=nContactIndex;i<nContacts-1;i++)
    strcpy(contacts[i],contacts[i+1]);
  nContacts--;
  return SaveContacts(contacts,nContacts,users[userIndex].username);  
}

//send contact list
uint8_t SendContacts(user * users,uint16_t userIndex,uint16_t nClients)
{
  if (userIndex>=nClients) return FALSE;
  char contacts[MAX_CONTACTS][MAX_USERNAME+1];
  uint8_t online[MAX_CONTACTS];
  memset(online,0,MAX_CONTACTS);
  uint16_t nContacts=ReadContacts(contacts,users[userIndex].username);
  uint16_t i;
  for(i=0;i<nContacts;i++) 
    online[i]=(FindIndexByUserName(contacts[i],users,nClients)>=0);
  return SendUserList(users[userIndex].sock,users[userIndex].username,contacts,online,nContacts); //to implement 
}

//process message from client
uint8_t SRVProcessMessage(uint16_t userIndex,user * users,uint16_t nClients,UserPort ** userPorts,uint16_t * nPorts, uint8_t * buffer)
{
   if ((users==NULL)||(userIndex>=nClients)) return FALSE;
   char command;
   char username[MAX_USERNAME+1];
   time_t mtime;
   uint8_t * msg=DecodeMessage(buffer,&command,username,&mtime);
   if (msg==NULL) 
   {
      printf("Could not decode message\n");
      return FALSE;
   } 
   char password[256];
   uint16_t port=0;
   
   switch(command)
   {
    case CMD_LOGIN://login request
    case CMD_SIGNUP://signing up request
    case CMD_CHGPWD:if (msg!=NULL) buf2str(password,msg,255);break;//changing password
    case CMD_ANSWER://answer call, find new port for conversation between 2 users
    case CMD_ANSWER_OK:port=FindPort(users[userIndex].username,username,*userPorts,*nPorts);break;//confirm answering call
   }
   int toUserIndex=-1;
   switch(command)
   {
     case CMD_CALL:
     case CMD_ANSWER:
     case CMD_ANSWER_OK:
     case CMD_REJECT:
     case CMD_RECEIVED:
     case CMD_NOT_RECEIVED:
     case CMD_MSG:
     case CMD_FILE:
     case CMD_FILEPART:toUserIndex=FindIndexByUserName(username,users,nClients);break;
   }
   char cmdOK='\0';
   char cmdError='\0';
   uint8_t action=TRUE;
   uint8_t ret=TRUE;
   char message[256];
   message[0]='\0';
   uint32_t partno=0;
   switch(command)
   {
      case CMD_ADDCONTACT://adding contact request
      {
        cmdOK=CMD_OK_ADDC;
        cmdError=CMD_ERR_ADDC;
        action=AddContact(users,userIndex,username,nClients);
      };break;
      case CMD_DELCONTACT://deleting contact request
      {
        cmdOK=CMD_OK_DELC;
        cmdError=CMD_ERR_DELC;
        action=DelContact(users,userIndex,username,nClients);
      };break;
      case CMD_SHOWCONTACTS://request to show contact list
      {
        cmdError=CMD_ERROR_SHOWC;
        action=SendContacts(users,userIndex,nClients);
      };break;
      case CMD_LOGIN://login request
        {
          cmdOK=CMD_OK_LOGIN;
          cmdError=CMD_ERR_LOGIN;
          action=chkLogin(username,password,users,nClients);
          if (action) 
          {
             strcpy(users[userIndex].username,username);
             action=AddUserPort(username,users,nClients,userPorts,nPorts);
          }
          sprintf(message,(action)?"%s logged in":"Could not log in  %s",username);
        };break;
       case CMD_SIGNUP://signing up request
        {
          cmdOK=CMD_OK_SIGNUP;
          cmdError=CMD_ERR_SIGNUP;
          action=chkSignup(username,password,users,nClients);//,*talking,*nTalking);
          if (action)
             action=AddUser(username,password);
          if (action) 
          {
             strcpy(users[userIndex].username,username);
             action=AddUserPort(username,users,nClients,userPorts,nPorts);
          }
          sprintf(message,(action)?"%s signed up":"Could not sign up %s",username);  
        };break;   
      case CMD_CHGPWD://change password
       {
         cmdOK=CMD_OK_CHGPWD;
         cmdError=CMD_ERR_CHGPWD;
         action=ChangePassword(username,password);
         sprintf(message,"%s %s password",username,(action)?"changed":"could not change");
       };break;  
      case CMD_CALL://call
        {
          cmdError=CMD_ERR_CALL;
          if (toUserIndex<0)
            action=FALSE;
          else
            action=SendSimpleMessage(users[toUserIndex].sock,users[userIndex].username,CMD_CALL);  
          sprintf(message,"%s %s %s",users[userIndex].username,(action)?"calls":"cannot call",username);  
        };break; 
       case CMD_ANSWER://answer call
       {
         cmdError=CMD_ERR_ANSWER;
         if ((toUserIndex<0)||(port==0)) 
           action=FALSE;
         else
           action = SendMessageWithAddr(users[toUserIndex].sock,users[userIndex].username,CMD_ANSWER,users[userIndex].ip,port);
         sprintf(message,"%s %s %s",users[userIndex].username,(action)?"answered":"could not answer",username);
       };break;   
       case CMD_ANSWER_OK://confirm answering call
       {
         cmdError=CMD_ERR_ANSWER;
         if ((toUserIndex<0)||(port==0)) 
           action=FALSE;
         else
           action = SendMessageWithAddr(users[toUserIndex].sock,users[userIndex].username,CMD_ANSWER_OK,users[userIndex].ip,port);
         
         sprintf(message,"%s answer to %s",(action)?"Confirmed":"Could not confirm",username);   
       };break;      
      case CMD_REJECT://reject call
       {
         if (toUserIndex<0)
           action=FALSE;
         else  
           action=SendSimpleMessage(users[toUserIndex].sock,users[userIndex].username,CMD_REJECT);
         sprintf(message,"%s call from %s %s",username,(action)?"rejected":"could not reject",users[userIndex].username); 
       };break;    
    case CMD_FILE://small file
    case CMD_FILEPART:partno=(command==CMD_FILE)?0:buf2int32(msg+260)+1;//part of a large file
    case CMD_MSG://text message
    case CMD_RECEIVED://file received
    case CMD_NOT_RECEIVED://file not received
    {
      if ((command==CMD_FILE)||(command==CMD_FILEPART)||(command==CMD_MSG))
      {
        cmdOK=(command==CMD_MSG)?CMD_OK_MSG:CMD_OK_FILE;
        cmdError=(command==CMD_MSG)?CMD_ERR_MSG:CMD_ERR_FILE;
      }
      if (toUserIndex<0)
        action=FALSE;
      else
      {
        action=SendBytes(users[toUserIndex].sock,users[userIndex].username,msg,command,mtime); 
        sprintf(message,"%s was %s sent to %s",
             (command==CMD_MSG)?"Message":(((command==CMD_RECEIVED)||(command==CMD_NOT_RECEIVED))?"Confirmation":"File"),(action)?"":"not",username);
      }
    };break;   
   }//end switch
   
   char cmd=(action)?cmdOK:cmdError;
   if (cmd!='\0')
   {
     if ((cmd==CMD_OK_FILE)||(cmd==CMD_ERR_FILE))
       ret=SendNum(users[userIndex].sock,username,cmd,partno);
     else
       ret=SendSimpleMessage(users[userIndex].sock,username,cmd);
   }
   if (strlen(message))//display status message,if any 
     printf("%s\n\r",message);
   switch(command)
   {
     case CMD_SIGNUP:
     case CMD_LOGIN:if (action) SendSavedMessages(users[userIndex].sock,username);break;//send all saved messages for logged in user
     case CMD_FILE:
     case CMD_FILEPART:
     case CMD_MSG:if (!action) SaveMessage(username,users[userIndex].username,buffer);break;//if message not sent - save it to database
   }   
   return ret;
}

//print all users in database
void PrintUsers()
{
   char fn[256];
   MakeFileName(fn,DBPATH,DBNAME,F_END);
   FILE * fptr=fopen(fn,"rb");
   if (fptr==NULL)
   {
     printf("No users exist\n");
     return;
   }
   fseek(fptr,0,SEEK_END);
   size_t filesize=ftell(fptr);
   size_t elements=filesize/sizeof(UserRec);
   if (elements<=0)
   {
     fclose(fptr);
     printf("No users exist\n\r");
     return;
   }
   UserRec * buf=(UserRec*)malloc(elements*sizeof(UserRec));
   if (buf==NULL)
   {
     printf("Cannot display users\n\r");
     fclose(fptr);
     return;
   }
   fseek(fptr,0,SEEK_SET);
   fread(buf,elements*sizeof(UserRec),1,fptr);
   fclose(fptr);
   printf("%d users exist/s\n",elements);
   size_t i;
   for(i=0;i<elements;i++)
     printf("Username:%s, password:%s\n\r",buf[i].username,buf[i].password);
   free(buf);
}

//add new client socket
int32_t AddSocket(user ** users,uint16_t * nClients,int new_socket,struct sockaddr_in * address)
{
   if ((users==NULL)||(nClients==NULL)||(address==NULL)||(address==NULL)) return -1;
   uint16_t tmpClients = *nClients;
   user * tmpUsers= *users;
   user * newUsers=(user*)malloc((tmpClients+1)*sizeof(user));
   if ((tmpUsers!=NULL)&&(tmpClients>0))
     memcpy(newUsers,tmpUsers,tmpClients*sizeof(user));
   if (tmpUsers!=NULL)
   {
     free(tmpUsers);
     tmpUsers=NULL;
   }  
   
   newUsers[tmpClients].sock = new_socket;
   newUsers[tmpClients].ip=ipstr2n(inet_ntoa((*address).sin_addr));
   newUsers[tmpClients].port=(*address).sin_port;
   newUsers[tmpClients].username[0]='\0';
             
    * users=newUsers;
    * nClients=tmpClients+1;
    return (int32_t)tmpClients;
}

//remove client socket from sockets array if disconnected 
uint8_t RemoveSocket(user ** users,uint16_t index,uint16_t * nClients)
{
  if ((users==NULL)||(nClients==NULL)) return FALSE;
  if ((*users==NULL)||(*nClients==0)||(index>= *nClients)) return FALSE;
  user * newUsers=NULL;
  user * tmpUsers= *users;
  uint16_t tmpClients= *nClients;
  if (tmpClients>1)
    newUsers=(user*)malloc((tmpClients-1)*sizeof(user));
  if ((index>0)&&(tmpUsers!=NULL))
    memcpy(newUsers,tmpUsers,index*sizeof(user));  
  if ((tmpClients-index-1>0)&&(tmpUsers!=NULL))
    memcpy(newUsers,tmpUsers+index+1,(tmpClients-index-1)*sizeof(user));
  if (tmpUsers!=NULL) 
  { 
     free(tmpUsers);
     tmpUsers=NULL;
  }
  *users=newUsers;
  *nClients=tmpClients-1;
  return TRUE;  
}

//save text message to database
uint8_t SaveMessage(char * toUsername,char * fromUsername,uint8_t * buffer)
{
  char command;
  uint8_t buf2[MAX_MSG_BUF+1];
  char username[MAX_USERNAME+1];
  time_t mtime;
  uint8_t * msg=DecodeMessage(buffer,&command,username,&mtime);
  if (msg==NULL) return FALSE;
  if (!FormatMessage(command,fromUsername,msg,mtime,buf2)) return FALSE;
  
  char filename[256];
  
  MakeFileName(filename,DBPATH,toUsername,F_END);
  return AddMessage(buf2,filename);
}

//send all saved messages for an user
uint8_t SendSavedMessages(int sock,const char * username)
{
  char filename[256];
  
  MakeFileName(filename,DBPATH,username,F_END);
  MessagePtr * list = ReadList(filename);
  SendList(sock,&list);
  SaveList(list,filename);
  FreeList(&list);
}

//add port for future conversations of an user with rest of the users
uint8_t AddUserPort(char * username,user * users,uint16_t nClients,UserPort ** userPorts,uint16_t * nPorts)
{
  if ((users==NULL)||(nClients<2)) return TRUE;
  uint16_t old_size=*nPorts;
  uint16_t new_size=old_size+nClients-1;
  UserPort * new_ports=(UserPort*)malloc(new_size*sizeof(UserPort));
  if (*userPorts!=NULL)
  {
    memcpy(new_ports,*userPorts,old_size*sizeof(UserPort));
    free(*userPorts);
    *userPorts=NULL;
  }
  uint16_t i;
  uint16_t max_port=PORT;
  for(i=0;i<nClients;i++)
    if (users[i].port>max_port) max_port=users[i].port;
  for(i=0;i<old_size;i++)
   if (new_ports[i].port>max_port) max_port=new_ports[i].port;
  
  uint16_t j=old_size;
  for(i=0;i<nClients;i++)
  {
     if (!StrEqual(users[i].username,username))
     {
       strcpy(new_ports[j].user1,username);
       strcpy(new_ports[j].user2,users[i].username);
       max_port++;
       new_ports[j].port=max_port;
       j++;
     }
  }
  *userPorts=new_ports;
  *nPorts=new_size;
  return TRUE;
}

//find port for conversation between 2 users
uint16_t FindPort(char * user1,char * user2,UserPort * ports,uint16_t nPorts)
{
  if ((user1==NULL)||(user2==NULL)) return 0;
  if (StrEqual(user1,user2)) return 0;
  if ((ports==NULL)||(nPorts==0)) return 0;
  uint16_t i;
  for(i=0;i<nPorts;i++)
  {
    if ((StrEqual(ports[i].user1,user1))&&(StrEqual(ports[i].user2,user2)))
      return ports[i].port;
    if ((StrEqual(ports[i].user1,user2))&&(StrEqual(ports[i].user2,user1)))
      return ports[i].port;
  }
  return 0;
}

//free ports array
void FreePorts(UserPort ** userPorts,uint16_t * nPorts)
{
   if (nPorts!=NULL) *nPorts=0;
   if (userPorts==NULL) return;
   if (*userPorts==NULL) return;
   free(*userPorts);
   *userPorts=NULL;
}

//command text to number
int GetCommandNo(char * input_buffer)
{
  return IndexOfStrArray(input_buffer,ServerCommands,MAX_SN);
}

//print commands menu
void PrintMenu()
{
  printf("Available commands\n\r");
  int i;
  for(i=0;i<MAX_SN;i++)
    printf("%s\n\r",ServerCommands[i]);
}

//show who is online
void PrintOnlineUsers(user * users,uint16_t nClients)
{
  if ((nClients==0)||(users==NULL))
  {
     printf("Nobody is online\n\r");
     return;
  }
  printf("Online users:\n\r");
  int i;
  for(i=0;i<nClients;i++)
    if (users[i].sock>0)
      printf("%s\n\r",(strlen(users[i].username)>0)?users[i].username:"Unknown user");
}

//process input from console
uint8_t SRVProcessInput(char * input_buffer,user * users,uint16_t nClients)
{
  int nCommand=GetCommandNo(input_buffer);
  uint8_t ret=TRUE;
  switch(nCommand)
  {
   case SN_ABOUT:PrintAbout();break;//about the program
   case SN_MENU:PrintMenu();break;//show menu
   case SN_USERS:PrintUsers();break;//show users in database
   case SN_ONLINE:PrintOnlineUsers(users,nClients);break;//show online users
   case SN_STOPALL://stop server and all clients
      {
       int i;
       for(i=0;i<nClients;i++)
         if (users[i].sock>0)
           SendSimpleMessage(users[i].sock,users[i].username,CMD_STOP);
       ret=FALSE;
      };break;
   case SN_STOP:ret=FALSE;break;//stop server only
   default:printf("Command '%s' could not be recognized\n", input_buffer);
  }
  ClearString(input_buffer,MAX_INPUT_BUF+1);
  return ret;
}
