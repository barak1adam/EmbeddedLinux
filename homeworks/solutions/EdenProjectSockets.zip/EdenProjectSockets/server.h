#ifndef _SERVER_H
#define _SERVER_H
#include <inttypes.h>

#define DBPATH "serverdb"
#define DBNAME "chat"
#define TEMPFN "temp"
#define F_END "dxb"
#define F_CNT_END "cnt"
#define MAX_INPUT_BUF 20

#define S_MENU "MENU"
#define S_USERS "USERS"
#define S_ONLINE "LIST"
#define S_STOPALL "STOPALL"
#define S_STOP "STOP"
#define S_ABOUT "ABOUT"

#define SN_MENU 0
#define SN_USERS 1
#define SN_ONLINE 2
#define SN_STOPALL 3
#define SN_STOP 4
#define SN_ABOUT 5

#define MAX_SN 6

static char * ServerCommands[]={S_MENU,S_USERS,S_ONLINE,S_STOPALL,S_STOP,S_ABOUT};

typedef struct _user
{
  char username[MAX_USERNAME+1];
  int sock;
  uint32_t ip;
  uint16_t port;
} user;


typedef struct _userRec
{
  char username[MAX_USERNAME+1];
  char password[256];
} UserRec;

typedef struct _userPort
{
  char user1[MAX_USERNAME+1];
  char user2[MAX_USERNAME+1];
  uint16_t port;
} UserPort;

uint16_t ReadContacts(char contacts[][MAX_USERNAME+1],char * username);
uint8_t SaveContacts(char contacts[][MAX_USERNAME+1],uint16_t nContacts,char * username);
int FindContact(char contacts[][MAX_USERNAME+1],uint16_t nContacts,char * username);
 
uint8_t AddContact(user * users, uint16_t userIndex,char * aUsername,uint16_t nClients);
uint8_t DelContact(user * users,uint16_t userIndex,char * aUsername,uint16_t nClients);
uint8_t SendContacts(user * users,uint16_t userIndex,uint16_t nClients);

uint8_t AddUserPort(char * username,user * users,uint16_t nClients,UserPort ** userPorts,uint16_t * nPorts);
uint16_t FindPort(char * user1,char * user2,UserPort * ports,uint16_t nPorts);
void FreePorts(UserPort ** userPorts,uint16_t * nPorts);

uint8_t SendSavedMessages(int sock,const char * username);
uint8_t SaveMessage(char * toUsername,char * fromUsername,uint8_t * buffer);

int32_t FindIndexByUserName(const char * username,user * users,uint16_t nClients);
void FreeUsers(user ** users,uint16_t * nClients);

uint8_t FindInFile(const char * username,const char * password);

uint8_t ChangePassword(const char * username,const char * password);

uint8_t chkLogin(const char * username,const char * password, user * users,uint16_t nClients);

uint8_t chkSignup(const char * username,const char * password,user * users,uint16_t nClients);

uint8_t AddUser(const char * username,const char * password);

uint8_t SRVProcessMessage(uint16_t userIndex,user * users,uint16_t nClients,UserPort ** userPorts,uint16_t * nPorts, uint8_t * buffer);

void PrintUsers();

int32_t AddSocket(user ** users,uint16_t * nClients,int new_socket,struct sockaddr_in * address);
uint8_t RemoveSocket(user ** users,uint16_t index,uint16_t * nClients);

int GetCommandNo(char * input_buffer); 
void PrintMenu();
void PrintOnlineUsers(user * users,uint16_t nClients);
uint8_t SRVProcessInput(char * input_buffer,user * users,uint16_t nClients); 

#endif
