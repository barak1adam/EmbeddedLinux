#include "chat.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/stat.h>


uint8_t sr_locked=FALSE;//send/receive lock


uint8_t MakeDirectory(const char * dname)
{
  struct stat st = {0}; //create database directory if needed    
  if (stat(dname, &st) == -1) 
     mkdir(dname, 0700);
  struct stat st1={0};
  return (stat(dname, &st1) != -1);   
}

//about the program
void PrintAbout()
{
   printf("(C) All rights reserved to Eden Corech, 052-5113695\n\r"); 
}

//make full path name out of directory, filename and extension

void MakeFileName(char * result,const char * path,const char * filename,const char * ext)

{  
  if (result==NULL) return;
  
  result[0]='\0';
  
  int lPath=0;
  
  if (path!=NULL) lPath=strlen(path);
  int lFilename=0;
  if (filename!=NULL) lFilename=strlen(filename);
  int lExt=0;
  if (ext!=NULL) lExt=strlen(ext);
  if (lFilename<=0) return;
  if ((lPath<=0)&&(lExt<=0))
    strcpy(result,filename);
 
  else if ((lPath<=0)&&(lExt>0))
    
    sprintf(result,"%s.%s",filename,ext);
  
  else if ((lPath>0)&&(lExt<=0))
    
    sprintf(result,"%s/%s",path,filename);
  
  else 
    
    sprintf(result,"%s/%s.%s",path,filename,ext);    
      
}

//convert host name to IP
uint32_t HostName2IP(char * ip_str)
{
    struct hostent *he;
    struct in_addr **addr_list;
    int i;
         
    if ( (he = gethostbyname( ip_str ) ) == NULL) 
    {
        // get the host info
        herror("gethostbyname");
        return 0;
    }//
 
    addr_list = (struct in_addr **) he->h_addr_list;
     
    for(i = 0; addr_list[i] != NULL; i++) 
        //Return the first one;
        return ipstr2n(inet_ntoa(*addr_list[i]));  
    return 0;
}

//index of string in string array
int IndexOfStrArray(char * str,char * arr[],int arr_size)
{
  int i;
  for(i=0;i<arr_size;i++)
    if (StrEqual(str,arr[i])) return i;
  return -1;
}

void FreeSocket(int * sock,fd_set * readfds)
{
  if (sock==NULL) return;
  if (*sock<0) return;
  close(*sock);
  FD_CLR(*sock,readfds);
  *sock=-1;
}

void ClearEndOfString(char * str)
{
  if (str==NULL) return;
  uint32_t i;
  uint32_t l=strlen(str);
  for(i=l;i>0;i--)
  {
    if ((str[i-1]>' ')||(str[i-1]<'\0')) return;
    str[i-1]='\0';
  }
}

void ClearString(char * str,uint32_t len)
{
  if (str==NULL) return;
  memset(str,0,len*sizeof(char));
}

//4 bytes array to integer
uint32_t buf2int32(const uint8_t * buf)
{
   if (buf==NULL) return 0;
   return (uint32_t)(((uint32_t)buf[0]<<24)|((uint32_t)buf[1]<<16)|((uint32_t)buf[2]<<8)|(uint32_t)buf[3]);
}

//integer to 4 bytes array
uint8_t int322buf(uint32_t n,uint8_t * buf)
{
  if (buf==NULL) return FALSE;
  buf[0]=(uint8_t)((n&0xFF000000)>>24);
  buf[1]=(uint8_t)((n&0x00FF0000)>>16);
  buf[2]=(uint8_t)((n&0x0000FF00)>>8);
  buf[3]=(uint8_t)( n&0x000000FF);
  return TRUE;
}

//2 bytes array to integer
uint16_t buf2int16(const uint8_t * buf)
{
  if (buf==NULL) return 0;
  return (uint16_t)(((uint16_t)buf[0]<<8)|(uint16_t)buf[1]);
}

//integer to 2 bytes array
uint8_t int162buf(uint16_t n,uint8_t * buf)
{
  if (buf==NULL) return FALSE;
  buf[0]=((uint16_t)n&0xFF00)>>8;
  buf[1]= (uint16_t)n&0x00FF;
  return TRUE;
}

//delete file from disk
uint8_t RemoveFile(char * filename)
{
   if (!FileExists(filename)) return TRUE;
   if (remove(filename)>=0) return TRUE;
   FILE * fptr=fopen(filename,"wb");
   if (fptr==NULL) return FALSE;
   uint8_t bt=0;
   fwrite(&bt,sizeof(uint8_t),1,fptr);
   fclose(fptr);
   return TRUE;
}

//send message with lock
int my_send(int sock,uint8_t * buffer,uint32_t bufLen)
{
  if ((sock<=0)||(buffer==NULL)||(bufLen==0)) return -1;
  if (sr_locked) return -1;
  sr_locked=TRUE;
  int ret=send(sock,buffer,bufLen,0);
  sr_locked=FALSE;
  return ret;
}

//receive message with lock
int my_recv(int sock,uint8_t * buffer,uint32_t bufLen)
{
  if ((sock<=0)||(buffer==NULL)||(bufLen==0)) return -1;
  if (sr_locked) return -1;
  sr_locked=TRUE;
  int ret=recv(sock,buffer,bufLen,0);
  sr_locked=FALSE;
  return ret;
}

//show message contents
void ShowMessage(uint8_t * buffer,int bufLen)
{
  printf("Incoming message:\n\r");
  if (bufLen<0)
  {
     printf("Error receiving message (length<0)\n\r");
     return;
  }
  if (bufLen==0)
  {
     printf("Socket disconnected (length=0)\n\r");
     return;
  }
  if (bufLen<MAX_MSG_BUF)
  {
     char str[MAX_MSG_BUF+1];
     ClearString(str,MAX_MSG_BUF+1);
     buf2str(str,buffer,bufLen);
     printf("Message %s too short, %d bytes\n\r",str,bufLen);
     return;
  }
  char command;
  char username[MAX_USERNAME+1];
  time_t mtime;
  uint8_t * msg=DecodeMessage(buffer,&command,username,&mtime);
  if (msg=NULL)
  {
    printf("Cannot decode message\n\r");
    return;
  }
  char cmsg[MAX_MSG_BUF+1];
  uint32_t ip=0;
  uint16_t port=0;
  char ipstr[MAX_IP_LEN];
  uint32_t filelen=0;
  uint32_t partno=0;
  uint32_t partlen=0;
  char filename[256];
  char u[MAX_USERNAME+1];
  uint16_t nContacts=0;
  switch(command)
  {
    case CMD_OK_SHOWC:nContacts=buf2int16(msg);break;
    case CMD_LOGIN:
    case CMD_SIGNUP:
    case CMD_CHGPWD:
    case CMD_MSG:buf2str(cmsg,msg,MAX_MSG_BUF-MAX_USERNAME-2);break;
    case CMD_ANSWER:
    case CMD_ANSWER_OK:
     {
        if (ExtractAddress(msg,&ip,&port))
          ipn2str(ip,ipstr);
        else
          ipstr[0]='\0';  
     };break;
   case CMD_RECEIVED:buf2str(u,msg+256,MAX_USERNAME);
   case CMD_FILE:
   case CMD_FILEPART:
    {
      buf2str(filename,msg,255);
      if (command!=CMD_RECEIVED)
        filelen=buf2int32(msg+256);
      if (command==CMD_FILEPART)
      {
        partno=buf2int32(msg+260);
        partlen=buf2int32(msg+264);
      }
    };break;  
  }
  switch(command)
  {
     case CMD_LOGIN:printf("Login password:%s",cmsg);break;
     case CMD_SIGNUP:printf("Sign up password:%s",cmsg);break;
     case CMD_CHGPWD:printf("Change password to %s",cmsg);break;
     case CMD_CALL:printf("Call");break;;    
     case CMD_ANSWER:printf("Answer,address:%s:%d",ipstr,port);break;
     case CMD_MSG:printf("Message %s",cmsg);break;
     case CMD_OK_MSG:printf("Message OK");break;
     case CMD_ERR_MSG:printf("Message error");break;
     case CMD_OK_FILE:printf("File OK");break;
     case CMD_ERR_FILE:printf("File error");break;
     case CMD_FILE:printf("File data,filename=%s,file size=%d",filename,filelen);break;
     case CMD_FILEPART:printf("File part no.%d,length%d,filename=%s,file size==%d",partno,partlen,filename,filelen);break;
     case CMD_HANGUP:printf("Hang up");break;
     case CMD_OK_LOGIN:printf("Login OK");break;
     case CMD_OK_SIGNUP:printf("Sign up OK");break;
     case CMD_OK_CHGPWD:printf("Password changed");break;
     case CMD_ERR_LOGIN:printf("Login error");break;
     case CMD_ERR_CHGPWD:printf("Error changing password");break;
     case CMD_ERR_SIGNUP:printf("Error signing up");break;
     case CMD_ERR_CALL:printf("Error calling");break;
     case CMD_ERR_ANSWER:printf("Error answering");break;
     case CMD_UNKNOWN:printf("Unknown command");break;
     case CMD_REJECT:printf("Reject");break;
     case CMD_ANSWER_OK:printf("Answer OK");break;
     case CMD_SERVER_DOWN:printf("Server down");break;
     case CMD_RECEIVED:
     case CMD_NOT_RECEIVED:printf("File %s %s received from %s",filename,(command==CMD_NOT_RECEIVED)?"not":"",u);break;
     case CMD_STOP:printf("Stop");break;
     case CMD_DELCONTACT:printf("Delete contact");break;
     case CMD_ADDCONTACT:printf("Add contact");break;
     case CMD_SHOWCONTACTS:printf("Show contacts");break;
     case CMD_OK_ADDC:printf("Contact added");break;
     case CMD_ERR_ADDC:printf("Error adding contact");break;
     case CMD_OK_DELC:printf("Contact deleted");break;
     case CMD_ERR_DELC:printf("Error deleting contact");break;
     case CMD_ERROR_SHOWC:printf("Show contact request");break;
     case CMD_OK_SHOWC:printf("Contact list, %d contacts",nContacts);break;
     default:printf("Unknown command:%c=%X",command,command);break;
  }
  struct tm * lt=localtime(&mtime);
  printf(" %02d/%02d/%04d %02d:%02d:%02d user=%s\n\r",lt->tm_mday,lt->tm_mon+1,lt->tm_year+1900,lt->tm_hour,lt->tm_min,lt->tm_sec,(strlen(username)>0)?username:"none");
}

//extract parts of message from message buffer: comand,username, time
//returns buffer to all the rest of the message buffer
uint8_t * DecodeMessage(uint8_t * buffer,char * command,char * username,time_t * mtime)
{
  if (buffer==NULL) return NULL;
  uint32_t i;
  if (command!=NULL) *command=CMD_UNKNOWN;
  if (command!=NULL) *command=(char)buffer[0];
  if (username!=NULL)
  {
    ClearString(username,MAX_USERNAME+1);
    buf2str(username,buffer+1,MAX_USERNAME);
  }
  if (mtime!=NULL)
    *mtime=(time_t)buf2int32(buffer+MAX_USERNAME+1);
  return buffer+MAX_USERNAME+5;
} 

//extract contact list from message buffer
uint16_t ExtractContacts(uint8_t * buffer,char contacts[][MAX_USERNAME+1],uint8_t * online)
{
  uint16_t i;
  uint32_t offset;
  uint16_t nContacts=buf2int16(buffer+MAX_USERNAME+5);
  if (nContacts>MAX_CONTACTS) nContacts=MAX_CONTACTS;
  for(i=0,offset=MAX_USERNAME+7;(i<nContacts)&&(offset<MAX_MSG_BUF);i++,offset+=(MAX_USERNAME+2))
  {
    memset(contacts[i],0,sizeof(char)*(MAX_USERNAME+1));
    buf2str(contacts[i],buffer+offset,MAX_USERNAME);
    online[i]=buffer[offset+MAX_USERNAME+1];
  }
  return nContacts;
}

//send contact list
uint8_t SendUserList(int sock,char * username,char contacts[][MAX_USERNAME+1],uint8_t * online,uint16_t nContacts)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=CMD_OK_SHOWC;
  time_t mtime=time(NULL);
  if (username!=NULL) str2buf(buffer+1,username);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  int162buf(nContacts,buffer+MAX_USERNAME+5);
  uint16_t i;
  uint32_t offset;
  for(i=0,offset=MAX_USERNAME+7;(i<nContacts)&&(offset<MAX_MSG_BUF);i++,offset+=(MAX_USERNAME+2))
  {
    str2buf(buffer+offset,contacts[i]);
    buffer[offset+MAX_USERNAME+1]=online[i];
  }
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//send confirmation for received file
uint8_t SendFileConfirmation(int sock,char command,char * filename,char * username,char * aUsername)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  time_t mtime=time(NULL);
  if (username!=NULL) str2buf(buffer+1,username);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (filename!=NULL) str2buf(buffer+MAX_USERNAME+5,filename);
  if (aUsername!=NULL) str2buf(buffer+MAX_USERNAME+261,aUsername);
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//format message buffer from parts: username, free series of bytes and time
uint8_t FormatMessage(char command,char * username, uint8_t * msg,time_t mtime,uint8_t * buffer)
{
  if (buffer==NULL) return FALSE;
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  str2buf(buffer+1,username);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (msg!=NULL) 
    memcpy(buffer+MAX_USERNAME+5,msg,MAX_MSG_BUF-MAX_USERNAME-5);
  return TRUE;  
}

//send string message
uint8_t SendString(int sock,char * username,char * str,char command,time_t mtime)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  if (username!=NULL) str2buf(buffer+1,username);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (str!=NULL) str2buf(buffer+MAX_USERNAME+5,str);
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//send 32-bit number
uint8_t SendNum(int sock,char * username,char cmd,uint32_t num)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=cmd;
  if (username!=NULL) str2buf(buffer+1,username);
  time_t mtime=time(NULL);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  int322buf(num,buffer+MAX_USERNAME+5);
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//send series of bytes
uint8_t SendBytes(int sock,char * username,uint8_t * bytes,char command,time_t mtime)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  if (username!=NULL) str2buf(buffer+1,username);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (bytes!=NULL) memcpy(buffer+MAX_USERNAME+5,bytes,MAX_MSG_BUF-5-MAX_USERNAME);
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//send message with username and command only
uint8_t  SendSimpleMessage(int sock,char * username,char command)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  str2buf(buffer+1,username);
  time_t mtime=time(NULL);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (username!=NULL) str2buf(buffer+1,username);
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
}

//send command, IP address and port
uint8_t SendMessageWithAddr(int sock,char * username,char command,uint32_t ip,uint16_t port)
{
  uint8_t buffer[MAX_MSG_BUF+1];
  memset(buffer,0,MAX_MSG_BUF+1);
  buffer[0]=command;
  if (username!=NULL) str2buf(buffer+1,username);
  time_t mtime=time(NULL);
  int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
  if (!EncodeAddress(buffer+MAX_USERNAME+5,ip,port)) return FALSE;
  return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
} 

//get file name and size from buffer
uint8_t * GetFileParams(uint8_t * msg,char * filename,uint32_t * filelen)
{
  if (msg==NULL) return NULL;
  buf2str(filename,msg,255);
  filename[255]='\0';
  *filelen=buf2int32(msg+256);
  return msg+260;
}

//get file part number and length from buffer
void GetFilePartParams(uint8_t * msg,char * filename,uint32_t * filelen, uint32_t * nPartNo,uint32_t * nPartLen)
{
   if (msg==NULL) return;
   if (filename!=NULL) buf2str(filename,msg,255);
   if (filelen!=NULL) *filelen=buf2int32(msg+256);
   if (nPartNo!=NULL) *nPartNo=buf2int32(msg+260);
   if (nPartLen!=NULL) *nPartLen=buf2int32(msg+264);
}

//get file part parameters and contents, and array of parts
uint8_t GetFilePart(uint8_t * msg,char * filename, uint32_t ** fileparts, uint32_t * nParts,uint32_t * nPartNo,uint32_t * filelen,uint8_t ** filedata)
{
   *filelen=buf2int32(msg+256);
   *nPartNo=buf2int32(msg+260);
   uint32_t partlen=buf2int32(msg+264);
   uint32_t chunk_len=MAX_MSG_BUF-MAX_USERNAME-1-256-8-1-4;
   uint32_t elements=*nParts;
   if (*filedata==NULL) *filedata=newBuffer(*filelen);
   if (*fileparts==NULL)
   {
      elements=*filelen/chunk_len;
      if (*filelen%chunk_len>0)
         elements++;
      *nParts=elements;
      *fileparts=newUint32(elements);  
   } 
          
   buf2str(filename,msg,255);
            
   if (*nPartNo<elements) 
   {
     (*fileparts)[*nPartNo]=partlen;
     if (*filedata==NULL) *filedata=newBuffer(*filelen);
     memcpy(*filedata+*nPartNo*chunk_len,msg+268,partlen);
   }
   uint32_t i;
   for(i=0;i<(*nParts);i++)
     if ((*fileparts)[i]==0) return FALSE;
   return TRUE;
   
}

//temporary filename
uint8_t NewFileName(char * filename)
{
   if (filename==NULL) return FALSE;
   int32_t p=lastpos('.',filename);
   char ending[256];
   if (p<0)
     ending[0]='\0';
   else
     strcpy(ending,filename+p);
   char tempFileName[256];
   uint16_t i;
   for(i=0;i<10000;i++)
   {
     sprintf(tempFileName,"TEMP%d%s",i+1,ending);
     if (!FileExists(tempFileName))
     {
       strcpy(filename,tempFileName);
       return TRUE;
     }
   }    
   return FALSE;
}

//file contents to buffer 
void GetFileBuffer(uint8_t * buffer,char * filename,uint32_t * filelen,uint32_t partlen,uint32_t start)
{
   if ((buffer==NULL)||(filename==NULL)||(filelen==NULL)&&(partlen==0)) return;
   FILE * fptr=fopen(filename,"rb");
   if (fptr==NULL) return;
   uint32_t toRead;
   uint8_t toMove;
   if ((filelen!=NULL)&&(partlen==0))
   {
     fseek(fptr,0,SEEK_END);
     *filelen=ftell(fptr);
     toRead=*filelen;
     toMove=TRUE;
   }
   else
   {
     toMove=(start>0);
     toRead=partlen;
   }
   if (toMove)
     fseek(fptr,start,SEEK_SET);
   fread(buffer,toRead,1,fptr);
   fclose(fptr);
}

//file size
uint32_t GetFileSize(char * filename)
{
  FILE * fptr=fopen(filename,"rb");
  if (fptr==NULL) return 0;
  fseek(fptr,0,SEEK_END);
  uint32_t size=ftell(fptr);
  fclose(fptr);
  return size;
}

//send file
uint8_t SendFile(int sock,char * username,char * filename)
{
   uint8_t buffer[MAX_MSG_BUF+1];
   uint32_t filelen=GetFileSize(filename);
   
   uint32_t chunk_len=MAX_MSG_BUF-MAX_USERNAME-1-256-8-1-4;
   time_t mtime=time(NULL);
   if (filelen<chunk_len) //file small enough to be sent as single part
   {
     memset(buffer,0,MAX_MSG_BUF+1);
     buffer[0]=CMD_FILE;
     if (username!=NULL) str2buf(buffer+1,username);
     int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
     GetFileBuffer(buffer+MAX_USERNAME+5+260,filename,&filelen,0,0);
     str2buf(buffer+MAX_USERNAME+5,filename);
     int322buf(filelen,buffer+MAX_USERNAME+5+256);
     return (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
   }
   if (filelen==0)
   {
      printf("Could not access %s\n\r",filename);
      return TRUE;
   }

   //sending file by parts
   uint8_t ret=TRUE;
   
   uint32_t elements=filelen/chunk_len;
   if (elements%chunk_len>0)
      elements++;
   uint32_t i,j,partlen;
   for(i=0;(i<elements)&&(ret);i++)
   {
      if ((i<elements-1)||(elements%chunk_len==0))
         partlen=chunk_len;
      else
         partlen=elements%chunk_len; 
      memset(buffer,0,MAX_MSG_BUF+1);
      GetFileBuffer(buffer+MAX_USERNAME+5+268,filename,NULL,partlen,i*chunk_len);
      buffer[0]=CMD_FILEPART;
      str2buf(buffer+1,username); 
      int322buf((uint32_t)mtime,buffer+MAX_USERNAME+1);
      str2buf(buffer+MAX_USERNAME+5,filename);
      int322buf(filelen,buffer+MAX_USERNAME+5+256);
      int322buf(i,buffer+MAX_USERNAME+5+260);
      int322buf(partlen,buffer+MAX_USERNAME+5+264);
      ret = (my_send(sock,buffer,MAX_MSG_BUF)==MAX_MSG_BUF);
  }
  return ret;
}

//IP and port to buffer
uint8_t EncodeAddress(uint8_t * msg,uint32_t ip,uint16_t port)
{
  if (msg==NULL) return FALSE;
  int322buf(ip,msg);
  int162buf(port,msg+4);
  return TRUE; 
}

//IP and port from buffer
uint8_t ExtractAddress(const uint8_t * msg,uint32_t * ip,uint16_t  * port)
{
  if ((msg==NULL)||(ip==NULL)||(port==NULL)) return FALSE;
  *ip=buf2int32(msg);
  *port=buf2int16(msg+4);
  return TRUE;
}

//save file buffer to disk
uint8_t ReceiveFile(char * filename,const uint8_t * msg,uint32_t nLen)
{
  if ((msg==NULL)||(nLen<=0)||(filename==NULL)) return FALSE;
  if (strlen(filename)==0)
    strcpy(filename,"temp");
  FILE * fptr=fopen(filename,"wb");
  if (fptr==NULL) return FALSE;
  fwrite(msg,(size_t)nLen,1,fptr);
  fclose(fptr);
  return TRUE;
}

//get file contents
uint8_t * GetFileData(char * filename,uint32_t * filelen)
{
  if ((filename==NULL)||(filelen==NULL)) return NULL;
  FILE * fptr=fopen(filename,"rb");
  if (fptr==NULL) return NULL;
  fseek(fptr,0,SEEK_END);
  *filelen=(uint32_t)ftell(fptr);
  fseek(fptr,0,SEEK_SET);
  uint8_t * buffer=NULL;
  if (*filelen>0)
  {
    buffer=newBuffer(*filelen+1);
    fread(buffer,(size_t)(*filelen),1,fptr);
  }
  fclose(fptr);
  return buffer;
}

//if strings are equal, case insensitive (stricmp doesn't work)
uint8_t StrEqual(const char * str1,const char * str2)
{
   int l1=0;
   if (str1!=NULL) l1=strlen(str1);
   int l2=0;
   if (str2!=NULL) l2=strlen(str2);
   if (l1!=l2) return FALSE;
   int i;
   for(i=0;i<l1;i++)
     if (toupper(str1[i])!=toupper(str2[i]))
       return FALSE;
   return TRUE;
}

//check IP address string
uint8_t CorrectIPStr(char * ip)
{
  uint32_t v=ipstr2n(ip);
  return (v>0);
}

//IP string to integer
uint32_t ipstr2n(char * ip)
{
  if (ip==NULL) return 0;
  uint8_t arr[]={0,0,0,0};
  int l=strlen(ip);
  int i;
  uint8_t points;
  uint16_t cell;
  char c;
  for(i=0,points=0;i<l;i++)
  {
    c=ip[i];
    switch(c)
    {
       case '.':
       {
         if ((i==0)||(i==l-1)) return 0;
         if (ip[i-1]=='.') return 0;
         points++;
         if (points>3) return 0;
       };break;
       case '0':
       case '1':
       case '2':
       case '3':
       case '4':
       case '5':
       case '6':
       case '7':
       case '8':
       case '9':
          {
              cell=(uint16_t)arr[points]*10+(uint16_t)c-(uint16_t)'0'; 
              if (cell>=256) return 0;
              arr[points]=(uint8_t)cell; 
          };break;
       default:return 0;
       
    }
  }
  return buf2int32(arr);
}

//integer to IP string
uint8_t ipn2str(uint32_t ip,char * buf)
{
  if (buf==NULL) return FALSE;
  uint8_t arr[]={0,0,0,0};
  int322buf(ip,arr);
  sprintf(buf,"%d.%d.%d.%d",arr[0],arr[1],arr[2],arr[3]);
  return TRUE;
}

uint8_t FileExists(char * filename)
{
  if (filename==NULL) return FALSE;
  if (strlen(filename)==0) return FALSE;
  FILE * fptr=fopen(filename,"rb");
  if (fptr==NULL) return FALSE;
  fclose(fptr);
  return TRUE;
}

//last position of character within a string
int32_t lastpos(char c,char * s)
{
  if (s==NULL) return -1;
  uint32_t l=strlen(s);
  uint32_t i;
  for(i=l;i>0;i--)
    if (s[i-1]==c) 
      return i-1;
  return -1;       
}

//string to buffer
uint8_t str2buf(uint8_t * buffer,char * str)
{
  if ((buffer==NULL)||(str==NULL)) return FALSE;
  uint32_t l=strlen(str);
  uint32_t i;
  for(i=0;i<l;i++)
    buffer[i]=(uint8_t)str[i];
  buffer[l]=0;
  return TRUE;  
}

//buffer to string
uint8_t buf2str(char * str,uint8_t * buffer,uint32_t max_size)
{
  if ((str==NULL)||(buffer==NULL)) return FALSE;
  char * pstr;
  uint8_t * pbuf;
  uint32_t i;
  for(pstr=str,pbuf=buffer,i=0;(pstr!=NULL)&&(pbuf!=NULL)&&(i<max_size);i++,pstr++,pbuf++)
  {
     *pstr = (char)(*pbuf);
     if (*pbuf==0) break;
  }
  return TRUE;  
}

//allocate new  buffer
uint8_t * newBuffer(uint32_t size)
{
  if (size==0) return NULL;
  return (uint8_t*)malloc(size);
}

void FreeBuffer(uint8_t ** buffer)
{
  if (buffer==NULL) return;
  if (*buffer==NULL) return;
  free(*buffer);
  *buffer=NULL;
}

//allocate new integer array
uint32_t * newUint32(uint32_t size)
{
  if (size==0) return NULL;
  uint32_t * ret = (uint32_t*)malloc(size*sizeof(uint32_t));
  if (ret!=NULL) memset(ret,0,size*sizeof(uint32_t));
  return ret;
}

void FreeUint32(uint32_t ** ptr)
{
  if (ptr==NULL) return;
  if (*ptr==NULL) return;
  free(*ptr);
  *ptr=NULL;
}

//allocate new string
char * newString(uint32_t size)
{
  if (size==0) return NULL;
  return (char*)malloc(size*sizeof(char));
}

void FreeString(char ** str)
{
  if (str==NULL) return;
  if (*str==NULL) return;
  free(str);
  str=NULL;
}

//add message to database
uint8_t AddMessage(uint8_t * buffer,const char * filename)
{
  FILE * fptr=fopen(filename,"a+b");
  if (fptr==NULL) return FALSE;
  fwrite(buffer,MAX_MSG_BUF+1,1,fptr);
  fclose(fptr);
  return TRUE;
}

//send list of messages
void SendList(int sock,MessagePtr ** list)
{
  MessagePtr * prev=NULL;
  MessagePtr * ptr=*list;
  MessagePtr * aux=NULL;
  while (ptr!=NULL)
  {
    if (my_send(sock,ptr->buffer,MAX_MSG_BUF)==MAX_MSG_BUF)
    {
      aux=ptr;
      if (prev==NULL)
        *list=ptr->next;
      else
        prev->next=ptr->next;
      ptr=ptr->next;
      aux->next=NULL;
      free(aux);
          
    }
    else
    {
      prev=ptr;
      ptr=ptr->next;
    }
  }
}

//read list of messages from database
MessagePtr * ReadList(const char * filename)
{
  FILE * fptr=fopen(filename,"rb");
  if (fptr==NULL) return NULL;
  MessagePtr * list=NULL;
  uint8_t buf[MAX_MSG_BUF+1];
  MessagePtr * ptr=NULL;
  size_t br;
  while(!feof(fptr))
  {
    br=fread(buf,MAX_MSG_BUF+1,1,fptr);
    if (br<1) break;
    if (buf[0]==0) break;
    ptr=(MessagePtr*)malloc(sizeof(MessagePtr));
    if (ptr!=NULL)
    {
      memcpy(ptr->buffer,buf,MAX_MSG_BUF+1);
      ptr->next=list;
      list=ptr;
    }
  }
  fclose(fptr);
  return list;
}

//save list of messages to database
uint8_t  SaveList(MessagePtr *list,const char * filename)
{
  FILE * fptr=fopen(filename,"wb");
  if (fptr==NULL) return FALSE;
  MessagePtr * ptr;
  for(ptr=list;ptr!=NULL;ptr=ptr->next)
    fwrite(ptr->buffer,MAX_MSG_BUF+1,1,fptr);
  fclose(fptr);
  return TRUE;
}

//free messages list
void  FreeList(MessagePtr ** list)
{
  if (list==NULL) return;
  MessagePtr * ptr;
  while (*list!=NULL)
  {
    ptr= *list;
    *list =ptr->next;
    ptr->next=NULL;
    free(ptr);
  }
}

//if a character is control character
uint8_t is_ctl_chr(char c)
{
  return ((c>='\0')&&(c<=' '));
}

//get list of words (til 3) separated by space from long string
char ** GetWords(char * input_buffer,uint32_t * nWords)
{
  uint32_t input_len=0;
  if (input_buffer!=NULL)
    input_len=strlen(input_buffer);
  if (input_len==0)
  {
    if (nWords!=NULL) *nWords=0;
    return NULL;
  }
  
  uint32_t *wlen=newUint32(input_len);
  memset(wlen,0,input_len*sizeof(uint32_t));
  uint32_t *wstart=newUint32(input_len);
  memset(wstart,0,input_len*sizeof(uint32_t));
  uint32_t tmpWords=0;
  uint32_t current=0;
  uint32_t i;
  char c;
  char cprev;
  for(i=0;i<input_len;i++)
  {
    c=input_buffer[i];
    if (!is_ctl_chr(c))
    {
      if ((is_ctl_chr(cprev))||(i==0))
      {
        if (i>0) current++;
        wstart[current]=i;
      }
      wlen[current]++;
    }
    cprev=c;
  }
  tmpWords=current;
  if (wlen[current]==0) tmpWords++;
  char ** ret=(char**)malloc(tmpWords*sizeof(char*));
  for(i=0;i<tmpWords;i++)
  {
    ret[i]=(wlen[i]>0)?newString(wlen[i]+1):NULL;
    if (ret[i]!=NULL)
      strncpy(ret[i],input_buffer+wstart[i],wlen[i]);
  }
  
  FreeUint32(&wstart);
  FreeUint32(&wlen);
  if (nWords!=NULL) *nWords=tmpWords;
  return ret;
  
}

//count words separated by space from long string (til 3)
uint32_t CountWords(char * input_buffer,uint32_t * wstart,uint32_t * wlen)
{
  memset(wstart,0,3*sizeof(uint32_t));
  memset(wlen,0,3*sizeof(uint32_t));
  uint32_t i;
  char c;
  char cprev='\0';
  uint32_t l=strlen(input_buffer);
  uint32_t current=0;
  for(i=0;(i<l)&&(current<3);i++)
  {
    c=input_buffer[i];
    if (!is_ctl_chr(c))
    {
      if ((is_ctl_chr(cprev))||(i==0))
      {
        if (i>0) current++;
        if (current<3) wstart[current]=i;
      }
      if (current<3) wlen[current]++;
    }
    cprev=c; 
  }
  for(i=0;i<3;i++)
    if (wlen[i]==0) return i;
  return 3;
}

