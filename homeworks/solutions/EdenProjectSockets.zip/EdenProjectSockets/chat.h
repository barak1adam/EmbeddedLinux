#ifndef _CHAT_H
#define _CHAT_H

#include <inttypes.h>
#include <time.h>
#include <sys/time.h>

#define TRUE   1
#define FALSE  0

//main server part
#define PORT 8888

//net message buffer size
#define MAX_MSG_BUF 4096
//max. length of username
#define MAX_USERNAME 10

//IP string length
#define MAX_IP_LEN 16

//address (IP+port) array length
#define ADDRESS_MSG_LEN 7

#define MAX_CONTACTS 300

//client commands
#define CMD_LOGIN 'A'
#define CMD_SIGNUP 'B'
#define CMD_CHGPWD 'C'
#define CMD_CALL 'D'
#define CMD_ANSWER 'E'
#define CMD_MSG 'F'
#define CMD_FILE 'G'
#define CMD_FILEPART 'H'
#define CMD_HANGUP 'I'
#define CMD_OK_LOGIN 'J'
#define CMD_OK_SIGNUP 'K'
#define CMD_OK_CHGPWD 'L'
#define CMD_ERR_CHGPWD 'M'
#define CMD_ERR_LOGIN 'N'
#define CMD_ERR_SIGNUP 'O'
#define CMD_ERR_CALL 'P'
#define CMD_ERR_ANSWER 'Q'
#define CMD_ERR_FILE 'R'
#define CMD_OK_FILE 'S'
#define CMD_ERR_MSG 'T'
#define CMD_OK_MSG 'U'
#define CMD_UNKNOWN 'W'
#define CMD_REJECT 'X'
#define CMD_ANSWER_OK 'Y'
#define CMD_SERVER_DOWN 'a'
#define CMD_RECEIVED 'b'
#define CMD_NOT_RECEIVED 'c'
#define CMD_STOP 'd'
#define CMD_DELCONTACT 'e'
#define CMD_ADDCONTACT 'f'
#define CMD_SHOWCONTACTS 'g'
#define CMD_OK_ADDC 'h'
#define CMD_ERR_ADDC 'i'
#define CMD_OK_DELC 'j'
#define CMD_ERR_DELC 'k'
#define CMD_ERROR_SHOWC 'l'
#define CMD_OK_SHOWC 'm'

//list of messages
typedef struct _messagePtr
{
  uint8_t buffer[MAX_MSG_BUF+1];
  struct _messagePtr * next;
} MessagePtr;

//for functions documentation see chat.c

uint16_t ExtractContacts(uint8_t * buffer,char contacts[][MAX_USERNAME+1],uint8_t * online);
uint8_t SendUserList(int sock,char * username,char contacts[][MAX_USERNAME+1],uint8_t * online,uint16_t nContacts); 
uint8_t MakeDirectory(const char * dname);
void PrintAbout();
void MakeFileName(char * result,const char * path,const char * filename,const char * ext);
uint32_t HostName2IP(char * ip_str);
int IndexOfStrArray(char * str,char * arr[],int arr_size);
void FreeSocket(int * sock,fd_set * readfds);
uint32_t buf2int32(const uint8_t * buf);
uint8_t int322buf(uint32_t n,uint8_t * buf);
uint16_t buf2int16(const uint8_t * buf);
uint8_t int162buf(uint16_t n,uint8_t * buf);
uint8_t NewFileName(char * filename);
uint8_t * GetFileParams(uint8_t * msg,char * filename,uint32_t * filelen);
uint8_t GetFilePart(uint8_t * msg,char * filename, uint32_t ** fileparts, uint32_t * nParts,uint32_t * nPartNo,uint32_t * filelen,uint8_t ** filedata);
void GetFilePartParams(uint8_t * msg,char * filename,uint32_t * filelen, uint32_t * nPartNo,uint32_t * nPartLen);
void ClearEndOfString(char * str);
void ClearString(char * str,uint32_t len);
uint8_t RemoveFile(char * filename);
MessagePtr * ReadList(const char * filename);
uint8_t  SaveList(MessagePtr *list,const char * filename);
void  FreeList(MessagePtr ** list);
void SendList(int sock,MessagePtr ** list);
uint8_t AddMessage(uint8_t * buffer,const char * filename);
int my_send(int sock,uint8_t * buffer,uint32_t bufLen);
int my_recv(int sock,uint8_t * buffer,uint32_t bufLen);
void ShowMessage(uint8_t * buffer,int bufLen);
uint8_t * DecodeMessage(uint8_t * buffer,char * command,char * username,time_t * mtime);
uint8_t FormatMessage(char command,char * username, uint8_t * msg,time_t mtime,uint8_t * buffer);
uint8_t SendString(int sock,char * username,char * str,char command,time_t mtime);
uint8_t SendBytes(int sock,char * username,uint8_t * bytes,char command,time_t mtime);
uint8_t SendNum(int sock,char * username,char cmd,uint32_t num);
uint8_t SendSimpleMessage(int sock,char * username,char command);
uint8_t SendMessageWithAddr(int sock,char * username,char command,uint32_t ip,uint16_t port);
uint8_t SendFile(int sock,char * username,char * filename);
uint8_t ExtractAddress(const uint8_t * msg,uint32_t * ip,uint16_t  * port);
uint8_t EncodeAddress(uint8_t * msg,uint32_t ip,uint16_t port);
uint8_t ReceiveFile(char * filename,const uint8_t * msg,uint32_t nLen);
uint8_t * GetFileData(char * filename,uint32_t * filelen);
uint32_t GetFileSize(char * filename);
uint8_t StrEqual(const char * str1,const char * str2);
uint8_t CorrectIPStr(char * ip);
uint32_t ipstr2n(char * ip);
uint8_t ipn2str(uint32_t ip,char * buf);
uint8_t FileExists(char * filename);
int32_t lastpos(char c,char * s);  
uint8_t str2buf(uint8_t * buffer,char * str);
uint8_t buf2str(char * str,uint8_t * buffer,uint32_t max_size);
uint8_t * newBuffer(uint32_t size);
void FreeBuffer(uint8_t ** buffer);
uint32_t  * newUint32(uint32_t size);  
void FreeUint32(uint32_t ** ptr);
char * newString(uint32_t size);
void FreeString(char ** str);
char ** GetWords(char * input_buffer,uint32_t * nWords);
uint32_t CountWords(char * input_buffer,uint32_t * wstart,uint32_t * wlen);
uint8_t is_ctl_chr(char c);
void GetFileBuffer(uint8_t * buffer,char * filename,uint32_t * filelen,uint32_t partlen,uint32_t start);
uint8_t SendFileConfirmation(int sock,char command,char * filename,char * username,char * aUsername);
#endif
