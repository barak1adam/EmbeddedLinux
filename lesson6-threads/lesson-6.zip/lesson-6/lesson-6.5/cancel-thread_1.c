/* Listing 6.5 ( cancel-thread1.c) trying to kill a newly created thread.

Description
-----------
trying to kill a newly created thread.

Note: when compiling and link this program be sure to add the -lpthread library:
as the following:

% gcc cancel-thread_1.c -lpthread -ggdb -o cancel-thread_1



/* Questions
1. What is the stat variable used for? 
   does it indicate tha the target thread is terminated ?
2. Why is there a need for the 3 seconds sleep ? (line 43)
3. Is the created thread terminated ? WHY is that ? 
4. Please modify the source code so the created thread is terminated at the 9th itteration
*/


/*************  includes     *****************/
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>   //sleep()

/*************  Prototypes   *****************/
void* thread1_func();
int gCounter=0;



/*************  main() function ****************/ 
// The main program. 
int main ()
{
	pthread_t thread1_id;
	int stat =-1;

	/* Create a new thread to print 30,000 x's. */
	pthread_create (&thread1_id, NULL, thread1_func, NULL);

	sleep (3);

	printf("main():  Cancel the created thread\n");
	/* Cancel the thread */
	stat = pthread_cancel(thread1_id);
	
	while(1)
	{
		printf("main():  gCounter=%d \n",gCounter);
	}
	

	/* Now we can safely return. */
	return 0;
}

/*************  thread1_func() function ****************/
/* Prints a number of characters to stderr, as given by PARAMETERS,
which is a pointer to a struct char_print_parms. */
void* thread1_func(void)
{
	int i,j;
	for (i = 0; ; ++i)
	{
		for(j=0;j<0xfffffff;j++);
		gCounter++;
		
	}
	return NULL;
}



